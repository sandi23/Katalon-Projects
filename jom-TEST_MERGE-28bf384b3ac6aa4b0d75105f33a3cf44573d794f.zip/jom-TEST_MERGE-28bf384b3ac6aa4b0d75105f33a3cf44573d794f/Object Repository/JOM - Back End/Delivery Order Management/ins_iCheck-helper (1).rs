<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>ins_iCheck-helper (1)</name>
   <tag></tag>
   <elementGuidId>09ce2aa7-7e89-45a5-8c25-9a012d44973f</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;DataTables_Table_1&quot;]/tbody/tr[1]/td[8]/label/div/ins</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>id(&quot;DataTables_Table_1&quot;)/tbody[1]/tr[@class=&quot;odd&quot;]/td[@class=&quot;dt-center&quot;]/label[@class=&quot;radio-inline icheck hover&quot;]/div[@class=&quot;icheckbox_square-blue hover checked&quot;]/ins[@class=&quot;iCheck-helper&quot;]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>ins</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>iCheck-helper</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;DataTables_Table_1&quot;)/tbody[1]/tr[@class=&quot;odd&quot;]/td[@class=&quot;dt-center&quot;]/label[@class=&quot;radio-inline icheck hover&quot;]/div[@class=&quot;icheckbox_square-blue hover checked&quot;]/ins[@class=&quot;iCheck-helper&quot;]</value>
   </webElementProperties>
</WebElementEntity>
