<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>input_form-control text-center</name>
   <tag></tag>
   <elementGuidId>fd094bc6-25ed-4ff8-81ba-48afb4449540</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>input</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>value</name>
      <type>Main</type>
      <value>25</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>type</name>
      <type>Main</type>
      <value>text</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>form-control text-center</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;tab1default&quot;)/div[@class=&quot;row detail-panel&quot;]/div[@class=&quot;col-sm-4&quot;]/div[@class=&quot;panel panel-primary&quot;]/div[@class=&quot;panel-body clearfix&quot;]/div[@class=&quot;col-md-6&quot;]/div[@class=&quot;md-form info-form detail-panel-form&quot;]/input[@class=&quot;form-control text-center&quot;]</value>
   </webElementProperties>
</WebElementEntity>
