<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>preview</name>
   <tag></tag>
   <elementGuidId>6ae6f185-4f42-4c6a-a447-2f77f38f426d</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//*[@title = '1 - Photo Studio Minimalis White C']</value>
      </entry>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;content&quot;]/div/div/ul/li[2]/a/div/div[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>title</name>
      <type>Main</type>
      <value>1 - Photo Studio Minimalis White C</value>
   </webElementProperties>
</WebElementEntity>
