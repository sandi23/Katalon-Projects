<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_No</name>
   <tag></tag>
   <elementGuidId>e3e1f7cf-29b7-4660-9595-61dbc1b27e27</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>table-responsive</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                
                    
                        
                            No
                            Name
                            Qty
                        
                    
                    
                                                    
                                
                                    1
                                
                                
                                    1x Cetak Photo + Frame E03m Putih 12R
                                    
                                
                                
                                    1
                                    
                                
                            

                                                    
                                
                                    2
                                
                                
                                    5x Cetak Photo 4R
                                    
                                
                                
                                    1
                                    
                                
                            

                                                    
                                
                                    3
                                
                                
                                    1x CD + Amplop
                                    
                                
                                
                                    1
                                    
                                
                            

                                            
                
                
            </value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;modal-action&quot;)/div[@class=&quot;modal-dialog&quot;]/div[@class=&quot;modal-content modal-slug modal-taking-order&quot;]/div[@class=&quot;modal-body&quot;]/form[@class=&quot;form-horizontal&quot;]/div[@class=&quot;box-body&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-12 col-lg-12 component-table&quot;]/fieldset[1]/div[@class=&quot;table-responsive&quot;]</value>
   </webElementProperties>
</WebElementEntity>
