<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>destination</name>
   <tag></tag>
   <elementGuidId>d4fe898a-10ab-47a4-abab-4cc7ef3218ae</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;form-price-template&quot;]/div[1]/div[4]/div/div[1]/div[2]/div[13]/div[1]/h4</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
