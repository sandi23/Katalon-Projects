<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>shipping</name>
   <tag></tag>
   <elementGuidId>429b42aa-5633-4ac1-b524-43b1f31d052a</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;form-price-template&quot;]/div[1]/div[4]/div/div[1]/div[2]/h4[2]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
</WebElementEntity>
