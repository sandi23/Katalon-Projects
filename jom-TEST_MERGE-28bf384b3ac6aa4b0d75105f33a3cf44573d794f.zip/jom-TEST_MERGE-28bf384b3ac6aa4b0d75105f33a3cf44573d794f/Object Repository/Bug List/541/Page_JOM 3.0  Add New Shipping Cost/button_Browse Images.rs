<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_Browse Images</name>
   <tag></tag>
   <elementGuidId>49e6cfb3-50e7-48fd-a7af-1bc242535a29</elementGuidId>
   <selectorCollection>
      <entry>
         <key>XPATH</key>
         <value>//*[@id=&quot;retail&quot;]/div/div[1]/button/i</value>
      </entry>
      <entry>
         <key>BASIC</key>
         <value>//button[@type = 'button' and (text() = '
                             Browse Images
                        ' or . = '
                             Browse Images
                        ')]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>XPATH</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>button</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>type</name>
      <type>Main</type>
      <value>button</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>btn btn-primary button-browse button-browse-retail-images</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                             Browse Images
                        </value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;retail&quot;)/div[@class=&quot;form-group form-product-printing-retail&quot;]/div[@class=&quot;col-sm-12 col-md-12 col-lg-12&quot;]/button[@class=&quot;btn btn-primary button-browse button-browse-retail-images&quot;]</value>
   </webElementProperties>
</WebElementEntity>
