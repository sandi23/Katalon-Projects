<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>input_form-control input-print</name>
   <tag></tag>
   <elementGuidId>bbbde6d5-83df-429c-99df-23a1072aa769</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>input</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>type</name>
      <type>Main</type>
      <value>number</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>form-control input-print-retail-qty</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;retail&quot;)/div[@class=&quot;form-group form-product-printing-retail&quot;]/div[@class=&quot;col-sm-12 col-md-12 col-lg-12&quot;]/div[@class=&quot;select-print-same&quot;]/div[@class=&quot;form-group form-product-printing-retail&quot;]/div[@class=&quot;col-sm-3 col-md-2 col-lg-2&quot;]/input[@class=&quot;form-control input-print-retail-qty&quot;]</value>
   </webElementProperties>
</WebElementEntity>
