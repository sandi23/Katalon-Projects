<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Produk yang Anda pilih 1 p</name>
   <tag></tag>
   <elementGuidId>e593ca2a-d240-4a98-ae21-174b28170c07</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>//div[@id = 'modal-choice-printing-package']</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>modal fade in</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>id</name>
      <type>Main</type>
      <value>modal-choice-printing-package</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-keyboard</name>
      <type>Main</type>
      <value>false</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-backdrop</name>
      <type>Main</type>
      <value>static</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tabindex</name>
      <type>Main</type>
      <value>-1</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>role</name>
      <type>Main</type>
      <value>dialog</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-labelledby</name>
      <type>Main</type>
      <value>myModalLabel</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
	
		


  
    Produk yang Anda pilih: 1 paket
    
      Total Order: Rp 177.000
    
  



  
    
      
        
          Produk
          
          Harga
          Jumlah
          Total
          Hapus
        
      
      
                                                                                                      
                
                  
                    
                  
                
                
                  
                    
                        
                            
                                                                                                                                
                                                                Copy Paket Studio Mini Poster
                                                                                                                            
                        
                    
                  
                
                
                  
                    
                        
                                                      Rp 88.500
                                                  
                    
                  
                
                
                  
                    
                        
                            2
                        
                    
                  
                
                
                  
                      
                          
                                                          Rp 177.000
                                                      
                      
                    
                
                
                                    
                                      
                  
                
              
                                                
          
            Total Order : Rp 177.000
          
        
        
          
            
            
              Pilih Paket Lain
                              Selesai, Lanjutkan ke Order 
                          
          
        
      
    
  


	
</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;modal-choice-printing-package&quot;)</value>
   </webElementProperties>
</WebElementEntity>
