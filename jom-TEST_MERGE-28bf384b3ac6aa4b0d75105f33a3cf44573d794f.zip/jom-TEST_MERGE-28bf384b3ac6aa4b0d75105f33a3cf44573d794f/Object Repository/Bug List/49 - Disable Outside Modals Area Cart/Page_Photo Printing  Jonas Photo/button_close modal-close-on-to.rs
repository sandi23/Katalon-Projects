<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_close modal-close-on-to</name>
   <tag></tag>
   <elementGuidId>d3acf9a5-acae-481c-8879-5ec12e66c577</elementGuidId>
   <selectorCollection>
      <entry>
         <key>BASIC</key>
         <value>id(&quot;modal-choice-printing-package&quot;)/div[@class=&quot;modal-dialog large-modal&quot;]/div[@class=&quot;modal-content&quot;]/button[@class=&quot;close modal-close-on-top&quot;][count(. | //*[@class = 'close modal-close-on-top']) = count(//*[@class = 'close modal-close-on-top'])]</value>
      </entry>
   </selectorCollection>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>button</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>type</name>
      <type>Main</type>
      <value>button</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>close modal-close-on-top</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>data-dismiss</name>
      <type>Main</type>
      <value>modal</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-label</name>
      <type>Main</type>
      <value>Close</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;modal-choice-printing-package&quot;)/div[@class=&quot;modal-dialog large-modal&quot;]/div[@class=&quot;modal-content&quot;]/button[@class=&quot;close modal-close-on-top&quot;]</value>
   </webElementProperties>
</WebElementEntity>
