<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>span_glyphicon glyphicon-plus</name>
   <tag></tag>
   <elementGuidId>6a38f0d5-f356-4fea-a89f-f78da608bd08</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>span</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>glyphicon glyphicon-plus</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;print-choiceproduct&quot;)/div[@class=&quot;modal-dialog large-modal&quot;]/div[@class=&quot;modal-content modal-notif-reg&quot;]/div[@class=&quot;modal-body no-padding clearfix&quot;]/form[@class=&quot;reg-form col-md-12 reservation-form-input uploaded-form-input m-40-auto&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;input-field no-padding-left no-padding-right&quot;]/div[@class=&quot;input-group number-spinner printing-qty&quot;]/span[@class=&quot;input-group-btn&quot;]/button[@class=&quot;btn btn-right waves-effect waves-light&quot;]/span[@class=&quot;glyphicon glyphicon-plus&quot;]</value>
   </webElementProperties>
</WebElementEntity>
