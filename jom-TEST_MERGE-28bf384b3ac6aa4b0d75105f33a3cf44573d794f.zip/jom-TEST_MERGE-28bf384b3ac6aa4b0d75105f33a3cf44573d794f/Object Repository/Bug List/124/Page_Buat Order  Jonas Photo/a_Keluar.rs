<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Keluar</name>
   <tag></tag>
   <elementGuidId>b5f3b320-83e1-41db-9ba9-1c6876956ff6</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>http://jom-demo-banda.stagingapps.net/user/logout?redirect=http://jom-demo-banda.stagingapps.net/studio/order/checkout?step=review</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>waves-effect waves-light</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value> Keluar</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;loaded&quot;]/header[1]/div[@class=&quot;container&quot;]/div[@class=&quot;row&quot;]/nav[@class=&quot;navbar nav-wrapper no-margin&quot;]/div[@class=&quot;container-fluid&quot;]/div[@class=&quot;collapse navbar-collapse&quot;]/div[@class=&quot;navbar-form navbar-right no-margin no-padding&quot;]/ul[@class=&quot;menu-wrapper nav navbar-nav&quot;]/li[1]/div[@class=&quot;dropdown open&quot;]/ul[@class=&quot;dropdown-menu&quot;]/li[5]/a[@class=&quot;waves-effect waves-light&quot;]</value>
   </webElementProperties>
</WebElementEntity>
