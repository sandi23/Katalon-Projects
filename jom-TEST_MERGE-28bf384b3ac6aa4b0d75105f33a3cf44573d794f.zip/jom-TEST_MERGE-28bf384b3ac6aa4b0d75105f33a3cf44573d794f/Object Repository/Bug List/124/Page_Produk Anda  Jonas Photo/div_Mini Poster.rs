<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Mini Poster</name>
   <tag></tag>
   <elementGuidId>bf9c2d33-d195-4686-a403-9f1d2138cd09</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h3</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Mini Poster</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;tour-catalog-2&quot;)/div[@class=&quot;row masonry-container&quot;]/div[@class=&quot;col-md-4 col-sm-6 item&quot;]/div[@class=&quot;thumbnail thumbnail-relative&quot;]/a[1]/div[@class=&quot;caption&quot;]/h3[1]</value>
   </webElementProperties>
</WebElementEntity>
