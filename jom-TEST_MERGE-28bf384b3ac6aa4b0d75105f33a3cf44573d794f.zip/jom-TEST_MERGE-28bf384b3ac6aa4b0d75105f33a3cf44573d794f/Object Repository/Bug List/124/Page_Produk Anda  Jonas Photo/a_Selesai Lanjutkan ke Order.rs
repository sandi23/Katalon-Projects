<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>a_Selesai Lanjutkan ke Order</name>
   <tag></tag>
   <elementGuidId>8f772de1-b5a0-45d5-b687-697eee73d7a5</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>a</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>href</name>
      <type>Main</type>
      <value>http://jom-demo-banda.stagingapps.net/studio/order/checkout</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>waves-effect waves-light btn-submit btn-gold-effect goto-checkout-studio</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Selesai, Lanjutkan ke Order </value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;modal-choiceproduct&quot;)/div[@class=&quot;modal-dialog large-modal&quot;]/div[@class=&quot;modal-content&quot;]/div[@class=&quot;modal-body no-padding&quot;]/div[@class=&quot;table-responsive table-modalproduct&quot;]/table[@class=&quot;table product-table&quot;]/tbody[1]/tr[@class=&quot;transparent&quot;]/td[@class=&quot;no-padding&quot;]/div[@class=&quot;input-field clearfix btn-loginsubmit no-padding-top pull-right&quot;]/a[@class=&quot;waves-effect waves-light btn-submit btn-gold-effect goto-checkout-studio&quot;]</value>
   </webElementProperties>
</WebElementEntity>
