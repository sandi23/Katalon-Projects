<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Photo On Studio</name>
   <tag></tag>
   <elementGuidId>dac2c5a8-4681-431e-b66d-7c3fe6d25c4d</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>col-xs-10 caption</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                      Photo On Studio
                      
                    </value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;tour-category-1&quot;)/div[@class=&quot;col-md-6&quot;]/a[@class=&quot;big-category-link&quot;]/div[@class=&quot;box-order white-bg big-category-box&quot;]/div[@class=&quot;row caption-box&quot;]/div[@class=&quot;col-md-12&quot;]/div[@class=&quot;col-xs-10 caption&quot;]</value>
   </webElementProperties>
</WebElementEntity>
