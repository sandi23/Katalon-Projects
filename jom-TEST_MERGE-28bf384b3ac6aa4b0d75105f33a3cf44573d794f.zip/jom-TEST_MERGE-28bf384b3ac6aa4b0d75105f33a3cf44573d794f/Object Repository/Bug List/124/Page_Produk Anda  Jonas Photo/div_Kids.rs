<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Kids</name>
   <tag></tag>
   <elementGuidId>3d27a3fa-7f83-4067-986e-37d7edef3729</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h5</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>title text-center no-margin</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Kids</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;tour-sub-category-1&quot;)/a[3]/div[@class=&quot;item-rectangle-25 col-xs-4 item-subcategory&quot;]/div[@class=&quot;content&quot;]/div[@class=&quot;box-order white-bg box&quot;]/h5[@class=&quot;title text-center no-margin&quot;]</value>
   </webElementProperties>
</WebElementEntity>
