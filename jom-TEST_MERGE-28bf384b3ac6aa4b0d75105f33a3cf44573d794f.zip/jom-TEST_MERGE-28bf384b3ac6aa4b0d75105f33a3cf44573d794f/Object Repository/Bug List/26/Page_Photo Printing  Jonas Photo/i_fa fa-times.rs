<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>i_fa fa-times</name>
   <tag></tag>
   <elementGuidId>bfed69db-852f-474c-8013-1a571c4849f4</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>i</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>fa fa-times</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-hidden</name>
      <type>Main</type>
      <value>true</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;step-1&quot;)/div[@class=&quot;box-order&quot;]/div[@class=&quot;flat-box recapitulation-your-photo no-padding-bottom&quot;]/div[@class=&quot;recap-table edit-advance&quot;]/div[@class=&quot;table-responsive table-modalproduct no-padding-left no-padding-right&quot;]/table[@class=&quot;table product-table summary-table&quot;]/tbody[1]/tr[@class=&quot;print-image-row&quot;]/td[3]/table[@class=&quot;uploaded-form-input&quot;]/tbody[1]/tr[@class=&quot;print-product&quot;]/td[8]/button[@class=&quot;btn btn-sm btn-primary btn-delete remove-product waves-effect waves-light&quot;]/i[@class=&quot;fa fa-times&quot;]</value>
   </webElementProperties>
</WebElementEntity>
