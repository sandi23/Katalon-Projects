<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h5_Cetak Photo 3R</name>
   <tag></tag>
   <elementGuidId>ba46768d-8b4f-4285-ae20-627a7fedbe3c</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h5</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Cetak Photo 3R</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;small-print&quot;)/table[@class=&quot;table table-hover no-margin&quot;]/tbody[1]/tr[1]/td[@class=&quot;product&quot;]/h5[1]</value>
   </webElementProperties>
</WebElementEntity>
