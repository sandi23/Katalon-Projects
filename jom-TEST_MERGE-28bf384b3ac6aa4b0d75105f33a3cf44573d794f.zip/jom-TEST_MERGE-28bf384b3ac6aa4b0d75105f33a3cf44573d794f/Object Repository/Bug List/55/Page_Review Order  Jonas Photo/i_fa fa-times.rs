<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>i_fa fa-times</name>
   <tag></tag>
   <elementGuidId>fb201998-7b7f-4df3-811b-7d49a1b5c6dd</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>i</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>fa fa-times</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>aria-hidden</name>
      <type>Main</type>
      <value>true</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;modal-choice-printing-package&quot;)/div[@class=&quot;modal-dialog large-modal&quot;]/div[@class=&quot;modal-content&quot;]/div[@class=&quot;modal-body no-padding&quot;]/div[@class=&quot;table-responsive table-modalproduct&quot;]/table[@class=&quot;table product-table&quot;]/tbody[1]/tr[1]/td[6]/button[@class=&quot;btn btn-sm btn-primary btn-delete waves-effect waves-light remove-cart-printing-package&quot;]/i[@class=&quot;fa fa-times&quot;]</value>
   </webElementProperties>
</WebElementEntity>
