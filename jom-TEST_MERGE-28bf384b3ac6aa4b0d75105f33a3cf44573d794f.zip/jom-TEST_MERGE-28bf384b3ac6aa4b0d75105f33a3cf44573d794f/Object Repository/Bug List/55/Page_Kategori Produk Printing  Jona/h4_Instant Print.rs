<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>h4_Instant Print</name>
   <tag></tag>
   <elementGuidId>1419f567-613d-4c0c-8ff9-893392d19582</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>h4</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Instant Print</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;content&quot;)/div[@class=&quot;landing&quot;]/div[@class=&quot;row&quot;]/div[@class=&quot;col-md-6&quot;]/a[@class=&quot;big-category-link&quot;]/div[@class=&quot;box-order white-bg big-category-box&quot;]/div[@class=&quot;row caption-box&quot;]/div[@class=&quot;col-md-12&quot;]/div[@class=&quot;col-xs-10 caption&quot;]/h4[1]</value>
   </webElementProperties>
</WebElementEntity>
