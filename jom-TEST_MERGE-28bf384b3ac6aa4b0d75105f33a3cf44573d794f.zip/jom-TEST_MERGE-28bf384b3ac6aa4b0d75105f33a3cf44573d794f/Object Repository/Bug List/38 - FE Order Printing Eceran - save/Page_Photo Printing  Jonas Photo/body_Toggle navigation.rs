<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>body_Toggle navigation</name>
   <tag></tag>
   <elementGuidId>97656de9-ac82-4e91-bffa-424e137462cf</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>body</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>loaded modal-open</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
    
    

  
  
  


    
  
    
      
        
          
            
              Toggle navigation
              
              
              
            
            
              
            
            
              
              Photo Printing
            
          
          
            
              
                                
                  Login
                
                                
                  
                  0
                
                
                  
                
                
                  
                  
                    
                                                                         Tentang Kami
                                                   Kontak
                                                   Karir
                                                   Term of Service
                                                   Privacy Policy
                                                                                        
                  
                
              
            
          
        
      
    
  

        
        
                
        
            
                
                    
                    Kembali ke Kategori
                
            
        

        
            
                
                  
                
                
                    
                        
                            
                                
                                    1 Foto
                                
                                
                                    1 Foto Terpilih
                                    
                                        
                                            
                                            Pilih Semua
                                        
                                    
                                    Hapus Foto Terpilih
                                
                            
                            
                                
                                    Upload Foto :
                                    
                                        BrowseJelajahi dari perangkat
                                        
                                    
                                
                            
                        

                        

                        
                                                                                                
                                        
                                            
                                                
                                                    
                                                    
                                                    
                                                        
                                                            
                                                        
                                                    
                                                
                                            
                                        
                                    
                                                                                    
                    
                
            
        

        
            
                
                Kembali
            

            
                Cetak Foto Ini
                
            
            1 Foto Terpilih
        

        
          
            
              
                
                  
                    
                  
                
                aaaa
                
            
        
    

    
    
        
            

            

                Anda Memiliki 1 Foto.Apakah mau dicetak dengan ukuran sama?

                
                    
                        
                            
                                + Tambah Cetakan
                                Jenis Cetak
                            

                            
                            
                        
                                                                                
                            
                            
                            
                                                
                            
                                Kertas
                                    Kertas
                                
                            
                            Kertas
                        
                        
                            
                                Warna
                                      Warna
                                
                            
                            Warna
                        

                        
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            
                            Harga Satuan
                        
                        
                            
                                
                                    
                                
                                
                                
                                    
                                
                            
                            Jumlah
                        

                        
                            
                            Harga Total
                        

                        
                            
                                
                            
                        
                    
                    Ya, Cetak Dengan Ukuran Diatas
                

                
                  
                  Atau
                  
                
                Tidak,  Cetak Dengan Beragam Ukuran
            
        
    


    
    
        
            Tambah Cetakan
            
                
                    
                                                    
                            
                                                                                                
                                                                                                                           
                                                                                                                                                                        
                                      Copy Paket Studio
                                    
                                                                                                                                                                                                                                                
                                      Large Print
                                    
                                                                                                                                                                                                                                                
                                      Custom Print
                                    
                                                                                                                                                                                                                                                
                                      Canvas Print
                                    
                                                                                                                                                                                                                                                
                                      Small Print
                                    
                                                                                                                                                                                                                                                
                                      Photo Blok
                                    
                                                                                                                                                                                                                                                
                                      Photo Frame
                                    
                                                                                                                                                                                                                                                
                                      Photo Matting
                                    
                                                                                                        
                                
                                  
                                  
                                                                        
                                                                                     
                                                                                    
                                                
                                                                                                                                                                                                                                                                
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Copy Paket Studio Mini Poster
                                                                                                                            
                                                            
                                                                                                                                Rp 88.500
                                                                                                                            
                                                        
                                                                                                                                                                                                                                                                        
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Copy Paket Studio Friendship
                                                                                                                            
                                                            
                                                                                                                                Rp 51.000
                                                                                                                            
                                                        
                                                                                                                                                                                                                                                                        
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Copy Paket Studio Action 7 &amp; 9
                                                                                                                            
                                                            
                                                                                                                                Rp 142.500
                                                                                                                            
                                                        
                                                                                                                                                                                                                                                                        
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Copy Paket Studio Retrovert
                                                                                                                            
                                                            
                                                                                                                                Rp 177.000
                                                                                                                            
                                                        
                                                                                                                                                                                                                                                                        
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Copy Paket Photo LONG
                                                                                                                            
                                                            
                                                                                                                                Rp 175.000
                                                                                                                            
                                                        
                                                                                                                                                                                                                                                                        
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Copy Paket Photo ME TOO
                                                                                                                            
                                                            
                                                                                                                                Rp 55.000
                                                                                                                            
                                                        
                                                                                                                                                                                                                                                                        
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Copy Paket Studio Holly Jolly
                                                                                                                            
                                                            
                                                                                                                                Rp 107.000
                                                                                                                            
                                                        
                                                                                                                                                                                                                
                                                
                                                                                
                                                                                     
                                                                                    
                                                
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Cetak Photo 12R
                                                                                                                            
                                                            
                                                                                                                                Rp 30.000
                                                                                                                            
                                                        
                                                                                                                                                                                                                                                                                                                                                                            
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Cetak Photo 12RP
                                                                                                                            
                                                            
                                                                                                                                Rp 42.001
                                                                                                                            
                                                        
                                                                                                                                                                                                                                                                                                                                                                            
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                 Cetak Photo + Laminasi 16R
                                                                                                                            
                                                            
                                                                                                                                Rp 88.000
                                                                                                                            
                                                        
                                                                                                                                                                                                                                                                        
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Cetak Photo + Laminasi 16RP
                                                                                                                            
                                                            
                                                                                                                                Rp 100.000
                                                                                                                            
                                                        
                                                                                                                                                                                                                                                                        
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Cetak Photo + Laminasi 20R
                                                                                                                            
                                                            
                                                                                                                                Rp 110.000
                                                                                                                            
                                                        
                                                                                                                                                                                                                                                                        
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Cetak Photo + Laminasi 20RP
                                                                                                                            
                                                            
                                                                                                                                Rp 122.000
                                                                                                                            
                                                        
                                                                                                                                                                                                                                                                        
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Cetak Photo + Laminasi 24R
                                                                                                                            
                                                            
                                                                                                                                Rp 218.000
                                                                                                                            
                                                        
                                                                                                                                                                                                                                                                        
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Cetak Photo + Laminasi 24RP
                                                                                                                            
                                                            
                                                                                                                                Rp 218.000
                                                                                                                            
                                                        
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Cetak Photo + Laminasi 12R
                                                                                                                            
                                                            
                                                                                                                                Rp 42.000
                                                                                                                            
                                                        
                                                                                                                                                                                                                                                                        
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Cetak Photo + Laminasi 12RP
                                                                                                                            
                                                            
                                                                                                                                Rp 54.000
                                                                                                                            
                                                        
                                                                                                                                                                                                                                                                        
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Cetak Glos + Lam 30x30cm
                                                                                                                            
                                                            
                                                                                                                                Rp 42.000
                                                                                                                            
                                                        
                                                                                                                                                                                                                                                                        
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Cetak Photo + Laminasi 30x60cm
                                                                                                                            
                                                            
                                                                                                                                Rp 76.000
                                                                                                                            
                                                        
                                                                                                                                                                                                                                                                        
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Cetak Photo + Laminasi 30x80cm
                                                                                                                            
                                                            
                                                                                                                                Rp 98.000
                                                                                                                            
                                                        
                                                                                                                                                                                                                                                                        
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Cetak Photo + Laminasi 30x90cm
                                                                                                                            
                                                            
                                                                                                                                Rp 116.000
                                                                                                                            
                                                        
                                                                                                                                                                                                                                                                        
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Cetak Photo + Laminasi 30R
                                                                                                                            
                                                            
                                                                                                                                Rp 319.000
                                                                                                                            
                                                        
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    
                                                
                                                                                
                                                                                     
                                                                                    
                                                
                                                                                                                                                            
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Cetak Doff Custom Size
                                                                                                                            
                                                            
                                                                                                                                Rp 1
                                                                                                                            
                                                        
                                                                                                                                                                                                                                                                        
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Cetak Kanvas Custom Size
                                                                                                                            
                                                            
                                                                                                                                Rp 1
                                                                                                                            
                                                        
                                                                                                                                                                                                                
                                                
                                                                                
                                                                                     
                                                                                    
                                                
                                                                                                                                                            
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Cetak Kanvas 12R
                                                                                                                            
                                                            
                                                                                                                                Rp 104.000
                                                                                                                            
                                                        
                                                                                                                                                                                                                                                                        
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Cetak Kanvas 12RP
                                                                                                                            
                                                            
                                                                                                                                Rp 114.000
                                                                                                                            
                                                        
                                                                                                                                                                                                                                                                        
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Cetak Kanvas 16R
                                                                                                                            
                                                            
                                                                                                                                Rp 200.000
                                                                                                                            
                                                        
                                                                                                                                                                                                                                                                        
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Cetak Kanvas 16RP
                                                                                                                            
                                                            
                                                                                                                                Rp 200.000
                                                                                                                            
                                                        
                                                                                                                                                                                                                                                                        
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Cetak Kanvas 20R
                                                                                                                            
                                                            
                                                                                                                                Rp 300.000
                                                                                                                            
                                                        
                                                                                                                                                                                                                                                                        
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Cetak Kanvas 20RP
                                                                                                                            
                                                            
                                                                                                                                Rp 300.000
                                                                                                                            
                                                        
                                                                                                                                                                                                                                                                        
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Cetak Kanvas 24R
                                                                                                                            
                                                            
                                                                                                                                Rp 400.000
                                                                                                                            
                                                        
                                                                                                                                                                                                                                                                        
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Cetak Kanvas 24RP
                                                                                                                            
                                                            
                                                                                                                                Rp 400.000
                                                                                                                            
                                                        
                                                                                                                                                                                                                                                                        
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Cetak Kanvas 30R
                                                                                                                            
                                                            
                                                                                                                                Rp 800.000
                                                                                                                            
                                                        
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
                                                
                                                                                
                                                                                     
                                                                                    
                                                
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Cetak Photo + Laminasi 3R
                                                                                                                            
                                                            
                                                                                                                                Rp 4.800
                                                                                                                            
                                                        
                                                                                                                                                                                                                                                                        
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Cetak Photo + Laminasi 4R
                                                                                                                            
                                                            
                                                                                                                                Rp 4.500
                                                                                                                            
                                                        
                                                                                                                                                                                                                                                                        
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Cetak Photo + Laminasi 5R
                                                                                                                            
                                                            
                                                                                                                                Rp 10.000
                                                                                                                            
                                                        
                                                                                                                                                                                                                                                                        
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Cetak Photo + Laminasi 6R
                                                                                                                            
                                                            
                                                                                                                                Rp 18.000
                                                                                                                            
                                                        
                                                                                                                                                                                                                                                                        
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Cetak Photo + Laminasi 8R
                                                                                                                            
                                                            
                                                                                                                                Rp 18.000
                                                                                                                            
                                                        
                                                                                                                                                                                                                                                                        
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Cetak Photo + Laminasi 8RP
                                                                                                                            
                                                            
                                                                                                                                Rp 21.000
                                                                                                                            
                                                        
                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                
                                                
                                                                                
                                                                                     
                                                                                    
                                                
                                                                                                                                                            
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Paket Blok 8RP Putih
                                                                                                                            
                                                            
                                                                                                                                Rp 51.000
                                                                                                                            
                                                        
                                                                                                                                                                                                                                                                        
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Paket Blok 8RP Hitam
                                                                                                                            
                                                            
                                                                                                                                Rp 51.000
                                                                                                                            
                                                        
                                                                                                                                                                                                                                                                        
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Paket Blok 12RP Putih
                                                                                                                            
                                                            
                                                                                                                                Rp 109.000
                                                                                                                            
                                                        
                                                                                                                                                                                                                                                                        
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Paket Blok 12RP Hitam
                                                                                                                            
                                                            
                                                                                                                                Rp 109.000
                                                                                                                            
                                                        
                                                                                                                                                                                                                                                                        
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Paket Blok 16RP Putih
                                                                                                                            
                                                            
                                                                                                                                Rp 195.000
                                                                                                                            
                                                        
                                                                                                                                                                                                                                                                        
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Paket Blok 16RP Hitam
                                                                                                                            
                                                            
                                                                                                                                Rp 195.000
                                                                                                                            
                                                        
                                                                                                                                                                                                                                                                        
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Paket Blok 20RP Putih
                                                                                                                            
                                                            
                                                                                                                                Rp 257.000
                                                                                                                            
                                                        
                                                                                                                                                                                                                                                                        
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Paket Blok 24RP Putih
                                                                                                                            
                                                            
                                                                                                                                Rp 373.000
                                                                                                                            
                                                        
                                                                                                                                                                                                                                                                        
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Paket Blok 30x30 Putih
                                                                                                                            
                                                            
                                                                                                                                Rp 92.000
                                                                                                                            
                                                        
                                                                                                                                                                                                                                                                        
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Paket Blok 30x60 Putih
                                                                                                                            
                                                            
                                                                                                                                Rp 161.000
                                                                                                                            
                                                        
                                                                                                                                                                                                                                                                                                                    
                                                
                                                                                
                                                                                     
                                                                                    
                                                
                                                                                                                                                            
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Paket Laminasi Frame 24RP Minimalis L060 Black
                                                                                                                            
                                                            
                                                                                                                                Rp 433.000
                                                                                                                            
                                                        
                                                                                                                                                                                                                                                                        
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Paket Laminasi Frame 24RP Minimalis L060 White
                                                                                                                            
                                                            
                                                                                                                                Rp 433.000
                                                                                                                            
                                                        
                                                                                                                                                                                                                                                                        
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Paket Laminasi Frame 20RP Minimalis L060 Black
                                                                                                                            
                                                            
                                                                                                                                Rp 267.000
                                                                                                                            
                                                        
                                                                                                                                                                                                                                                                        
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Paket Laminasi Frame 20RP Minimalis L060 White
                                                                                                                            
                                                            
                                                                                                                                Rp 267.000
                                                                                                                            
                                                        
                                                                                                                                                                                                                                                                        
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Paket Laminasi Frame 16RP Minimalis L023 Black
                                                                                                                            
                                                            
                                                                                                                                Rp 210.000
                                                                                                                            
                                                        
                                                                                                                                                                                                                                                                        
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Paket Laminasi Frame 16RP Minimalis L023 White
                                                                                                                            
                                                            
                                                                                                                                Rp 210.000
                                                                                                                            
                                                        
                                                                                                                                                                                                                                                                        
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Paket Laminasi Frame 12R Minimalis L023 Black
                                                                                                                            
                                                            
                                                                                                                                Rp 127.000
                                                                                                                            
                                                        
                                                                                                                                                                                                                                                                        
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Paket Laminasi Frame 12R Minimalis L023 White
                                                                                                                            
                                                            
                                                                                                                                Rp 127.000
                                                                                                                            
                                                        
                                                                                                                                                                                                                                                                        
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Paket Laminasi Frame 8R Minimalis E04P Black
                                                                                                                            
                                                            
                                                                                                                                Rp 56.000
                                                                                                                            
                                                        
                                                                                                                                                                                                                                                                        
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Paket Laminasi Frame 8R Minimalis E04P White
                                                                                                                            
                                                            
                                                                                                                                Rp 56.000
                                                                                                                            
                                                        
                                                                                                                                                                                                                                                                        
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Paket Kanvas Frame 80x120 Klasik 852 Tembaga Linen
                                                                                                                            
                                                            
                                                                                                                                Rp 2.520.000
                                                                                                                            
                                                        
                                                                                                                                                                                                                                                                        
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Paket Kanvas Frame 24RP Kla 852-1207 Tembaga Linen
                                                                                                                            
                                                            
                                                                                                                                Rp 1.385.000
                                                                                                                            
                                                        
                                                                                                                                                                                                                                                                        
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Paket Kanvas Frame 20RP Kla 852-1207 Tembaga Linen
                                                                                                                            
                                                            
                                                                                                                                Rp 1.150.000
                                                                                                                            
                                                        
                                                                                                                                                                                                                                                                        
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Paket Kanvas Frame 24RP Klasik NSJ20 Gold Linen
                                                                                                                            
                                                            
                                                                                                                                Rp 1.050.000
                                                                                                                            
                                                        
                                                                                                                                                                                                                                                                        
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Paket Kanvas Frame 20RP Klasik NSJ20 Gold Linen
                                                                                                                            
                                                            
                                                                                                                                Rp 775.000
                                                                                                                            
                                                        
                                                                                                                                                                                                                                                                        
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Paket Kanvas Frame 24RP Klasik KF 53 Gold
                                                                                                                            
                                                            
                                                                                                                                Rp 950.000
                                                                                                                            
                                                        
                                                                                                                                                                                                                                                                        
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Paket Kanvas Frame 20RP Klasik KF 53 Gold
                                                                                                                            
                                                            
                                                                                                                                Rp 700.000
                                                                                                                            
                                                        
                                                                                                                                                                                                                                                                        
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Paket Kanvas Frame 16RP Klasik KF 53 Gold
                                                                                                                            
                                                            
                                                                                                                                Rp 550.000
                                                                                                                            
                                                        
                                                                                                                                                                                                                                                                        
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Paket Kanvas Frame 24RP Klasik KJ 54 Silver
                                                                                                                            
                                                            
                                                                                                                                Rp 950.000
                                                                                                                            
                                                        
                                                                                                                                                                                                                                                                        
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Paket Kanvas Frame 20RP Klasik KJ 54 Silver
                                                                                                                            
                                                            
                                                                                                                                Rp 700.000
                                                                                                                            
                                                        
                                                                                                                                                                                                                                                                        
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Paket Kanvas Frame 16RP Klasik KJ 54 Silver
                                                                                                                            
                                                            
                                                                                                                                Rp 550.000
                                                                                                                            
                                                        
                                                                                                                                                                                                                                                                        
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Paket Kanvas Frame 24RP Klasik KS4 Putih
                                                                                                                            
                                                            
                                                                                                                                Rp 825.000
                                                                                                                            
                                                        
                                                                                                                                                                                                                                                                        
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Paket Kanvas Frame 24RP Klasik KS4 Gold
                                                                                                                            
                                                            
                                                                                                                                Rp 825.000
                                                                                                                            
                                                        
                                                                                                                                                                                                                                                                        
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Paket Kanvas Frame 20RP Klasik KS4 Gold
                                                                                                                            
                                                            
                                                                                                                                Rp 650.000
                                                                                                                            
                                                        
                                                                                                                                                                                                                                                                        
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Paket Kanvas Frame 20RP Klasik KS4 Putih
                                                                                                                            
                                                            
                                                                                                                                Rp 650.000
                                                                                                                            
                                                        
                                                                                                                                                                                                                                                                        
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Paket Kanvas Frame 16RP Klasik KS4 Gold
                                                                                                                            
                                                            
                                                                                                                                Rp 475.000
                                                                                                                            
                                                        
                                                                                                                                                                                                                                                                        
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Paket Kanvas Frame 16RP Klasik KS4 Putih
                                                                                                                            
                                                            
                                                                                                                                Rp 475.000
                                                                                                                            
                                                        
                                                                                                                                                                                                                
                                                
                                                                                
                                                                                     
                                                                                    
                                                
                                                                                                                                                                                                                                                                                                                                                                    
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Photo Matting 8R
                                                                                                                            
                                                            
                                                                                                                                Rp 10.000
                                                                                                                            
                                                        
                                                                                                                                                                                                                                                                        
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Photo Matting 8RP
                                                                                                                            
                                                            
                                                                                                                                Rp 10.000
                                                                                                                            
                                                        
                                                                                                                                                                                                                                                                        
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Photo Matting 12R
                                                                                                                            
                                                            
                                                                                                                                Rp 10.000
                                                                                                                            
                                                        
                                                                                                                                                                                                                                                                        
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Photo Matting 12RP
                                                                                                                            
                                                            
                                                                                                                                Rp 10.000
                                                                                                                            
                                                        
                                                                                                                                                                                                                                                                        
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Photo Matting 16R
                                                                                                                            
                                                            
                                                                                                                                Rp 20.000
                                                                                                                            
                                                        
                                                                                                                                                                                                                                                                        
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Photo Matting 16RP
                                                                                                                            
                                                            
                                                                                                                                Rp 20.000
                                                                                                                            
                                                        
                                                                                                                                                                                                                                                                        
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Photo Matting 20R
                                                                                                                            
                                                            
                                                                                                                                Rp 20.000
                                                                                                                            
                                                        
                                                                                                                                                                                                                                                                        
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Photo Matting 20RP
                                                                                                                            
                                                            
                                                                                                                                Rp 20.000
                                                                                                                            
                                                        
                                                                                                                                                                                                                                                                        
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Photo Matting 24R
                                                                                                                            
                                                            
                                                                                                                                Rp 20.000
                                                                                                                            
                                                        
                                                                                                                                                                                                                                                                        
                                                            
                                                                
                                                                    
                                                                    
                                                                

                                                                
                                                                                                                                
                                                                                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                                
                                                            
                                                            
                                                                                                                                
                                                                Photo Matting 24RP
                                                                                                                            
                                                            
                                                                                                                                Rp 20.000
                                                                                                                            
                                                        
                                                                                                                                                                                                                
                                                
                                                                                
                                                                            
                                                                       

                            
                        
                    

                
            
            
                
                    Batal
                    Simpan
                
            
        
    


    
  
      
      Pilih Frame
      
        
          
            
                                        
          
        
      
      
        
          Batal
          Simpan
        
      
    
  


        
    
    
  
    
      
      
        
          Login
          Daftar
        
        
          
            
              
                
                
                
                  
                  
                  Email atau Nomor Telepon
                
                
                  
                  
                  Password
                
                
                  Lupa Password? Klik Disini
                
                
                  Batal
                  Login
                
                
              
            
            
          
          
            
              
              
              
                
                
                
                  
                  Email
                
                
                  
                  Nomor Telepon
                
                
                  
                  Password
                  
                
                
                  
                     
                     
                     
                     
                    
                  
                
                
                  
                  Ulangi Password
                  
                
                
                  Sudah punya akun? Silakan Login
                
                
                  Batal
                  Daftar
                
                
              
            
            
          
        
      
    
  

  
    
      
      
        
          
          
            
              
                
                50% off
              
              
                Product Name
                Group
                
                  Rp. 100.000
                  Rp. 200.000
                
              
            
          
          
          
            
              
                
                Buy 1 Get 1
              
              
                Product Name
                Group
                
                  Rp. 200.000
                
              
            
          
          
          
            
              
                
                
              
              
                Product Name
                Group
                
                  Rp. 100.000
                  Rp. 200.000
                
              
            
            
              
                
              
              
              
                Product Name
                Group
                
                  Rp. 100.000
                  Rp. 200.000
                
              
            
            Free Item
            
              
                
                
              
              
                Product Name
                Group
                
                  Rp. 100.000
                  Rp. 200.000
                
              
            
            
              
                
              
              
              
                Product Name
                Group
                
                  Rp. 100.000
                  Rp. 200.000
                
              
            
          
        
      
    
  


  
    
      

      
        
        Pilih Store Jonas
        Jonas photo tersedia di banyak lokasi. Pilih yang terdekat dengan Anda.
        
          
            ▼Pilih Lokasi StoreBandung - BandaBandung - Buah BatuJakarta - Grand IndonesiaJakarta - Buah BatuJakarta - Plaza Indonesia
                Pilih Lokasi Store
                Bandung - Banda
                Bandung - Buah Batu
                Jakarta - Grand Indonesia
                Jakarta - Buah Batu
                Jakarta - Plaza Indonesia
               
               Jalan Banda No. 130,
            Babakan Ciparay, Bandung
          
        
      

      
        OK, Lanjutkan
      
    
  


  
    
        

    
        Produk yang Anda pilih: 0 paket
        
            Total Order: Rp 0
        
    



    
        
            
                
                    Produk
                    
                    Harga
                    Jumlah
                    Total
                    Hapus
                
            
            
                                    
                        Keranjang belanja anda kosong
                    
                                
                    
                        Total Order : Rp 0
                    
                
                
                    
                        
                        
                            Pilih Paket Lain
                                                        Selesai, Lanjutkan ke Order 
                                                    
                    
                
            
        
    

    
  


  
    
        


  
    Produk yang Anda pilih: 0 produk
    
      Total Order: Rp 0
    
  



  
    
      
        
          Produk
          
          Harga
          Jumlah
          Total
          Hapus
        
      
      
                  
            Keranjang belanja anda kosong
          
                
          
            Total Order: Rp 0
          
        
                
          
            
            
              Pilih Paket Lain
                              Selesai, Lanjutkan ke Order 
                          
          
        
      
    
  
    
  


  
    
      
      
        
        
          
            Berhubung order anda selesai di tanggal berbeda,Apakah anda akan mengirimkannya dalam waktu bersamaan ?
          
        
              
      
        Kirim bersamaan
        Kirim terpisah
      
    
  



  
    
      

      
        
          
          Pending
          
        
      

      
                


    
  


  
    
      

      
        
          
          feedback
          
        
      

      
        
          
            
              
                Image
                Description
              
            
            
            
          
        
      


    
  


  
    
        


    
        Produk yang Anda pilih: 0 paket
        
            Total Order: Rp 0
        
    



    
        
            
                
                    Produk
                    
                    Harga
                    Jumlah
                    Total
                    Hapus
                
            
            
                                    
                        Keranjang belanja anda kosong
                    
                                
                    
                        Total Order : Rp 0
                    
                
                
                    
                        
                        
                            Pilih Paket Lain
                                                            Selesai, Lanjutkan ke Order 
                                                    
                    
                
            
        
    

    
  


  
    
      
        Silahkan masukkan alamat email anda
        
          
          
          
            
            Email
          
          
            Batal
            Kirim
          
        
      
    
  


  
    
      
      
        
        
          
            Pembelanjaan Anda sudah mencapai batas minimal untuk reservasi.
            
            Anda bisa melakukan reservasi dengan memesan pada slot waktu yang tersedia tanpa harus mengantri.
          
        
      
      
        Non-Reservasi
        Reservasi
      
    
  

    
















    











    function removeHash () { 
        history.pushState(&quot;&quot;, document.title, window.location.pathname+window.location.search);
    }

    // Initialize collapse button
    $(&quot;.button-collapse&quot;).sideNav({
        menuWidth: 240,
        edge: 'right',
    });
    // Initialize collapsible (uncomment the line below if you use the dropdown variation)
    $('.collapsible').collapsible();

    $('select').material_select();

    /* Demo Scripts for Making Twitter Bootstrap 3 Tab Play Nicely With The Masonry Library
     * on SitePoint by Maria Antonietta Perna
     */

    //Initialize Masonry inside Bootstrap 3 Tab component

    var $container = $('.masonry-container');
    $container.imagesLoaded(function() {
        $container.masonry({
            columnWidth: '.item',
            itemSelector: '.item'
        });
    });

    //Reinitialize masonry inside each panel after the relative tab link is clicked -
    $('a[data-toggle=tab]').each(function() {
        var $this = $(this);

        $this.on('shown.bs.tab', function() {

            $container.imagesLoaded(function() {
                $container.masonry({
                    columnWidth: '.item',
                    itemSelector: '.item'
                });
            });

        }); //end shown
    });  //end each

    $('.carousel').carousel({
        interval: false
    });

    // Starrr plugin (https://github.com/dobtco/starrr)

    $('.starrr').starrr({
        readOnly: true
    });

    $(document).on('click', '.number-spinner button', function() {
        var btn = $(this),
                oldValue = btn.closest('.number-spinner').find('input').val().trim(),
                newVal = 0;

        if (btn.attr('data-dir') == 'up') {
            newVal = parseInt(oldValue) + 1;
        } else {
            if (oldValue > 1) {
                newVal = parseInt(oldValue) - 1;
            } else {
                newVal = 1;
            }
        }
        btn.closest('.number-spinner').find('input').val(newVal);

        return false;
    });

    $('.navbar-toggle').click(function() {
        $('.menu-wrapper').toggleClass('slide-in');
        $(this).toggleClass('slide-in');
        $('#main').toggleClass('body-slide-in');
    });

    $('.navbar-collapse.collapse .separator').parent('li').css(&quot;display&quot;, &quot;none&quot;);

    $('.circle-progress').circleProgress({
        value: 1,
        fill: {color: '#d4af37'}
        }).on('circle-animation-progress', function(event, progress) {
        $(this).find('strong').html(parseInt(100 * progress) + '&lt;i>%&lt;/i>');
    });
    
    function cleanString(string){
        return $.trim(string);
    }

    function showNotification(type, message){
        return '&lt;p class=&quot;light-green-info text-center notif-'+type+'&quot;>'+message+'&lt;/p>';
    }

    function addToCart(response, notifElem){
        $.ajax({
            url: 'http://jom-demo-banda.stagingapps.net/cart/printing/add',
            type: &quot;post&quot;,
            dataType: &quot;html&quot;,
            data: {
                type : response.type,
                image : response.image,
                name : response.name,
                components : response.components,
                qty : response.qty,
                price : response.price,
                total : response.total,
                redirect : response.redirect,
            },
            success: function(response){
                location.reload();
            }
        });
    }

    $('input[type=&quot;number&quot;]').keydown(function (e) {
        // Allow: backspace, delete, tab, escape, enter and .
        if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 39]) !== -1 ||
             // Allow: Ctrl+A, Command+A
            (e.keyCode === 65 &amp;&amp; (e.ctrlKey === true || e.metaKey === true)) || 
             // Allow: home, end, left, right, down, up
            (e.keyCode >= 35 &amp;&amp; e.keyCode &lt;= 37)) {
                 // let it happen, don't do anything
                 return;
                 
        }
        
        // Ensure that it is a number and stop the keypress
        if ((e.shiftKey || (e.keyCode &lt; 48 || e.keyCode > 57)) &amp;&amp; (e.keyCode &lt; 96 || e.keyCode > 105)) {
            e.preventDefault();
        }
    });

    $('input[type=&quot;number&quot;]').on('change', function (e) {
        if($(this).val() == ''){
            $(this).val('1');
        }
    });

    $(document).on('change', '.frame-radio', function(){
        $('.frame-radio').not(this).removeAttr('checked');
    });

    $(document).on('change', '.product-radio', function(){
        $('.product-radio').not(this).removeAttr('checked');
    });

    function formatCurrency(nStr){
        var prefix = 'Rp ';

        nStr += '';
        x = nStr.split('.');
        x1 = x[0];
        x2 = x.length > 1 ? '.' + x[1] : '';
        var rgx = /(\d+)(\d{3})/;
        while (rgx.test(x1)) {
            x1 = x1.replace(rgx, '$1' + '.' + '$2');
        }
        return prefix + x1 + x2;
    }

    function countGrandTotal(){
        var grand_total = 0;
        $.each($('.clean-price'), function(){
            grand_total = grand_total+parseInt($(this).val());
        });
        $('#grand-total').text(formatCurrency(grand_total));
        return false;
    }

    function copyValSubTotal(subtotal, pasteElement){
        $(pasteElement).val(subtotal);
    }

    function copyTextSubTotal(subtotal, pasteElement){
        $(pasteElement).text(subtotal);
    }

    $('.disabled-link').click(function(e){
        e.preventDefault();
    });

    $(document).on('keyup', '.login-steps .form-register #password', function(e){
        var string = $(this).val();
        App.password_information(string, this);
    });

    $(document).on('click', '#btn-finish', function(e){
        var url = $(this).data('url');
        var redirect = $(this).data('redirect');
        $.ajax({
            url: url,
            type: &quot;POST&quot;,
            dataType: &quot;JSON&quot;,
            data: {
                _token: &quot;Bx2HCRsvjKxckHcquC1OIWD5XbOvfzYrdjWQLyR0&quot;,
                redirect: redirect,
            },
            success: function(response){
                window.location.href = response.redirect;
            }
        });
        e.preventDefault();
    });

    $(document).on('click', '#checkout-tab-login-submit', function(e){
        var form = $(this).parents('form');
        $.ajax({
            url: $(form).attr('action'),
            type: &quot;POST&quot;,
            dataType: &quot;JSON&quot;,
            data: $(form).serialize(),
            success: function(response){
                if (response.meta.status==200) {
                    window.location.href = response.redirect;
                } else {
                    $(form).find('input[type=&quot;password&quot;]').val('');
                    $(form).find('input').removeClass('error').removeClass('valid');
                    $(form).find('label').attr('data-error','').attr('data-success', '');
                    if (response.data.message!=undefined) {
                        $(form).find('#username').addClass('error');
                        $(form).find('label[for=username]').attr('data-error', response.data.message);
                    }
                }
            }
        });
        e.preventDefault();
    });

    $(document).on('click', '#checkout-tab-register-submit', function(e){
        var form = $(this).parents('form');
        $.ajax({
            url: $(form).attr('action'),
            type: &quot;POST&quot;,
            dataType: &quot;JSON&quot;,
            data: $(form).serialize(),
            success: function(response){
                if (response.meta.status==200) {
                    window.location.href = response.redirect+'/#step-3';
                } else {
                    $(form).find('input[type=&quot;password&quot;]').val('');
                    $(form).find('input').removeClass('error').removeClass('valid');
                    $(form).find('label').attr('data-error','').attr('data-success', '');
                    if (response.data.email!=undefined) {
                        $(form).find('#email').addClass('error');
                        $(form).find('label[for=email]').attr('data-error', response.data.email[0]);
                    }
                    if (response.data.phone!=undefined) {
                        $(form).find('#phone').addClass('error');
                        $(form).find('label[for=phone]').attr('data-error', response.data.phone[0]);
                    }
                    if (response.data.password!=undefined) {
                        $(form).find('#password').addClass('error');
                        $(form).find('label[for=password]').attr('data-error', response.data.password[0]);
                    }
                }
            }
        });
        e.preventDefault();
    });




  $('.btn-next').on('click', function(){
    $('#modal-choiceproduct').modal('hide');
    $('#modal-choice-printing-package').modal('hide');
  });

    
        var baseUrl = document.location.origin;
        var currPhotos = 0;

        $(document).find('.printing_photos').each(function(){
            currPhotos++;
        });

        $('.input-first-upload').change(function() {
            console.log($(this).val());
            $('#first-upload').submit();
            return false;
        });

        $(document).on('click', '.modal-frame-tigger', function(){
            $('#frame-lists').html('');
            var item_code = $('#item_code').val();
            var item_type = $('#item_type').val();
            var sold_type = $('#sold-type').val();
            var selected_frame = $('#f_item_code').val();

            if((item_code) &amp;&amp; sold_type == 1){
                $.ajax({
                    url: &quot;http://jom-demo-banda.stagingapps.net/finishing/category/regular-print/instant/retail/frame-selection&quot;,
                    type: &quot;GET&quot;,
                    data:{
                        item_code: item_code,
                        item_type: item_type,
                        sold_type: sold_type,
                    },
                    success: function(data){
                        var response = $.parseJSON(data);
                        var checked = '';
                        var default_check = 'checked';
                        $.each(response.frames, function(key, value){
                            if(selected_frame == value.item_code){
                                checked = 'checked';
                                default_check = '';
                            }
                            $('#frame-lists').append(
                                '&lt;li class=&quot;col-md-4 item&quot;>'+
                                    '&lt;div class=&quot;form-group-on-jssor&quot;>'+
                                        '&lt;input type=&quot;radio&quot; class=&quot;filled-in frame-radio&quot; id=&quot;radio-'+parseInt(key+1)+'&quot; name=&quot;group-'+parseInt(key+1)+'&quot;'+checked+'>'+
                                        '&lt;label for=&quot;radio-'+parseInt(key+1)+'&quot;>'+
                                            '&lt;div class=&quot;frame-box&quot;>'+
                                                '&lt;div class=&quot;frame-top&quot;>'+
                                                    '&lt;img src=&quot;'+value.image+'&quot;>'+
                                                '&lt;/div>'+
                                                '&lt;div class=&quot;frame-bottom&quot;>'+
                                                    '&lt;p>'+value.name+'&lt;/p>'+
                                                    '&lt;span>'+formatCurrency(value.price)+'&lt;/span>'+
                                                    '&lt;input value=&quot;'+value.item_code+'&quot; class=&quot;frame_item_code&quot; type=&quot;hidden&quot;>'+
                                                    '&lt;input value=&quot;'+value.name+'&quot; class=&quot;frame_name&quot; type=&quot;hidden&quot;>'+
                                                    '&lt;input value=&quot;'+value.image+'&quot; class=&quot;frame_image&quot; type=&quot;hidden&quot;>'+
                                                    '&lt;input value=&quot;'+value.price+'&quot; class=&quot;frame_price&quot; type=&quot;hidden&quot;>'+
                                                '&lt;/div>'+
                                            '&lt;/div>'+
                                        '&lt;/label>'+
                                    '&lt;/div>'+
                                '&lt;/li>'
                            );
                        });

                        $('#frame-lists').prepend(
                            '&lt;li class=&quot;col-md-4 item&quot;>'+
                                '&lt;div class=&quot;form-group-on-jssor&quot;>'+
                                    '&lt;input type=&quot;radio&quot; class=&quot;filled-in frame-radio&quot; id=&quot;radio-0&quot; name=&quot;group-0&quot;'+default_check+'>'+
                                    '&lt;label for=&quot;radio-0&quot;>'+
                                        '&lt;div class=&quot;frame-box&quot;>'+
                                            '&lt;div class=&quot;frame-top&quot;>'+
                                                '&lt;i class=&quot;fa fa-ban fa-5x&quot; aria-hidden=&quot;true&quot;>&lt;/i>'+
                                            '&lt;/div>'+
                                            '&lt;div class=&quot;frame-bottom&quot;>'+
                                                '&lt;p>Tanpa Frame&lt;/p>'+
                                                '&lt;span>&lt;/span>'+
                                                '&lt;input value=&quot;&quot; class=&quot;no-frame frame_item_code&quot; type=&quot;hidden&quot;>'+
                                                '&lt;input value=&quot;no-frame&quot; class=&quot;frame_name&quot; type=&quot;hidden&quot;>'+
                                                '&lt;input value=&quot;&quot; class=&quot;frame_image&quot; type=&quot;hidden&quot;>'+
                                                '&lt;input value=&quot;0&quot; class=&quot;frame_price&quot; type=&quot;hidden&quot;>'+
                                            '&lt;/div>'+
                                        '&lt;/div>'+
                                    '&lt;/label>'+
                                '&lt;/div>'+
                          '&lt;/li>'
                        );
                    }
                });
            }
        });

        function make_enable_or_disable(){
            if($(document).find('#product-id').val() == ''){
                $('.printing-qty button').prop('disabled', true);
            }else{
                $('.printing-qty button').prop('disabled', false);
            }
        }
        make_enable_or_disable();
        $(document).on('click', '.submit-product', function(){
            if($('.product-radio:checked').length > 0){
                var elem = $('.product-radio:checked').parent().parent().parent();
                var product = elem.find('.product').html();
                var paperType = elem.find('.paper_type').val();
                var paperTypeId = elem.find('.paper_type').data('id');
                var price = cleanString(elem.find('.price').text());
                var priceAmount = elem.find('.price_amount').val();
                var originalPrice = elem.find('.original_price').val();
                var itemCode = elem.find('.item_code').val();
                var itemType = elem.find('.item_type').val();
                var soldType = elem.find('.sold_type').val();
                var image = elem.find('.image').val();
                var frame = elem.find('.frame').val();
                var product_id = elem.find('.product_id').val();

                $.ajax({
                    url: &quot;http://jom-demo-banda.stagingapps.net/finishing/category-retail/&quot;+product_id,
                    type: &quot;GET&quot;,
                    success: function(data){
                        $('#color').material_select('destroy');
                        $('#color').html(data);
                        $('#color').material_select();
                    }
                });
                $('#modal-add-print-container .button-add-print').html(product.replace(&quot;&lt;h5>&quot;, &quot;&quot;).replace(&quot;&lt;/h5>&quot;, &quot;&quot;));
                $('#product').html(product.replace(&quot;&lt;h5>&quot;, &quot;&quot;).replace(&quot;&lt;/h5>&quot;, &quot;&quot;)).hide();
                $('#product-id').val(product_id);
                // $('#product').show();
                $('#price').val(price);
                $('#sold-type').val(soldType);
                if(soldType == 0){
                    $('#frame-display').html('&lt;img class=&quot;&quot; height=&quot;60&quot; data-u=&quot;image&quot; src=&quot;'+frame+'&quot;>');
                    $('#f_image').val(frame);
                    $('#frame-display').addClass('disabled-link');
                    $('#frame-display').addClass('sold-type-package');
                }else{
                    $('#frame-display').html('+');
                }
                $('#original_price').val(originalPrice);
                $('#price_amount').val(priceAmount);

                $('#paper_type').html('&lt;option value=&quot;'+paperTypeId+'&quot;>'+paperType+'&lt;/option>');
                $('#paper_type').material_select();

                $('#total-price').val(price);

                $('#qty').val('1');
                $('#item_code').val(itemCode);
                $('#item_type').val(itemType);
                $('#image').val(image);

                $('#modal-add-print').modal('toggle');

                $('.btn-print-same-size').removeAttr('disabled');
                make_enable_or_disable();
                $('span.caret').remove();
            }

            return false;
        });

        $(document).on('click', '.submit-frame', function(){
            var elem = $('.frame-radio:checked').parent();
            var frame_item_code = elem.find('.frame_item_code').val();
            var frame_name = elem.find('.frame_name').val();
            var frame_image = elem.find('.frame_image').val();
            var frame_price = elem.find('.frame_price').val();
            var curr_price = $('#price_amount').val();
            var curr_total = $('#total-price').val();

            if(elem.find('.frame_item_code').hasClass('no-frame')){
                $('#frame-display').html('+');
                $('#f_item_code').val('');
                $('#f_name').val('');
                $('#f_image').val('');
                $('#f_price').val('0');
            }else{
                $('#frame-display').html('&lt;img class=&quot;&quot; height=&quot;60&quot; data-u=&quot;image&quot; src=&quot;'+frame_image+'&quot;>');
                $('#f_item_code').val(frame_item_code);
                $('#f_name').val(frame_name);
                $('#f_image').val(frame_image);
                $('#f_price').val(frame_price);
            }
            var new_price = parseInt(curr_price)+parseInt(frame_price);
            $('#price_amount').val(new_price);
            $('#price').val(formatCurrency(new_price));
            calculateSubtotal();

            $('#modal-select-frame').modal('toggle');

            return false;
        });

        $('#first-upload').ajaxForm({
            beforeSend: function (xhr, settings) {
                $(&quot;.alert&quot;).html(&quot;Photos selected, please wait for a moment..&quot;).show();
                setTimeout(function(){$(&quot;.alert&quot;).hide();}, 5000);
            },
            // uploadProgress: function(event, position, total, percentComplete) {
            // },
            complete: function(xhr, event, position, total, percentComplete) {
                var response = $.parseJSON(xhr.responseText);

                $.each(response.images, function( index, value ) {
                  // show progress div
                    $('.uploading-container').append('&lt;li class=&quot;in-progress&quot;>'
                        +'&lt;div id=&quot;circle-01&quot; class=&quot;circle-progress&quot; data-thickness=&quot;5&quot;>'
                            +'&lt;canvas width=&quot;0&quot; height=&quot;0&quot;>&lt;/canvas>'
                            +'&lt;strong>10&lt;i>%&lt;/i>&lt;/strong>'
                        +'&lt;/div>'
                        +'&lt;div class=&quot;file-name&quot;>Uploading...&lt;/div>'
                    +'&lt;/li>');
                  // animate progress
                    $('.circle-progress').circleProgress({
                        value: (percentComplete/100),
                        fill: {color: '#d4af37'}
                        }).on('circle-animation-progress', function(event, progress) {
                        $(this).find('strong').html(parseInt(100 * progress) + '&lt;i>%&lt;/i>');
                    });

                  // delay 3 seconds before showing image
                    setTimeout(function(){
                      //remove progress div
                      $(document).find('.in-progress').remove();

                      //show uploaded images
                      var count_now = $('.photo-count').text();
                      var count = parseInt(count_now)+1;
                      var text = count+' '+'Foto';
                      $('.photo-count').text(text);
                      $('.uploading-container').append('&lt;li>'
                          +'&lt;div class=&quot;file-img&quot;>'
                              +'&lt;div class=&quot;checklist-photo&quot;>'
                                  +'&lt;div class=&quot;form-group-on-jssor&quot;>'
                                      +'&lt;input type=&quot;checkbox&quot; class=&quot;printing_photos filled-in&quot; id=&quot;checkbox'+currPhotos+'&quot; name=&quot;printing_photos[]&quot;>'
                                      +'&lt;label for=&quot;checkbox'+currPhotos+'&quot;>'
                                      +'&lt;input type=&quot;hidden&quot; class=&quot;image_path&quot; value=&quot;'+value+'&quot;>'
                                          +'&lt;div class=&quot;box-template box-template-printing&quot;>'
                                              +'&lt;img class=&quot;&quot; data-u=&quot;image&quot; src=&quot;'+baseUrl+'/'+value+'&quot; />'
                                          +'&lt;/div>'
                                      +'&lt;/label>'
                                  +'&lt;/div>'
                              +'&lt;/div>'
                          +'&lt;/div>'
                      +'&lt;/li>');
                    currPhotos++;
                  }, 3000);
                });
            }
        });

        $(document).on('change', '.printing_photos', function(){
           getCheckedPhotos();
           if($(this).prop('checked')==false){
                $(&quot;#checkboxAll&quot;).prop('checked', false);
           }else{
                var checked = 0;
                var unchecked = 0;
                $(document).find('.printing_photos').each(function(){
                    if($(this).prop('checked')==true){
                        checked++;
                    }else{
                        unchecked++;
                    }
                });

                if((checked-unchecked)==checked){
                    $(&quot;#checkboxAll&quot;).prop('checked', true);
                }
           }
        });

        $(document).on('click', '#checkboxAll', function(){
            var t = $(this);

            if(t.is(':checked')){
                $(document).find('.printing_photos').each(function(){
                    $(this).prop('checked', true);
                });
            }else{
                $(document).find('.printing_photos').each(function(){
                    $(this).prop('checked', false);
                });
            }

            getCheckedPhotos();
        });

        $('.delete_selected_photo').click(function(){
            var images = [];

            var checked = 0;
            $(document).find('.printing_photos').each(function(){
                if($(this).prop('checked')==true){
                    checked++;
                }
            });

            if(checked>0){
                if (confirm(&quot;apakah anda yakin menghapus &quot;+checked+&quot; photo ini?&quot;)) {
                    $(document).find('.printing_photos:checked').each(function(){
                        var count_now = $('.photo-count').text();
                        var count = parseInt(count_now)-1;
                        var text = count+' '+'Foto';
                        $('.photo-count').text(text);
                        var path = $(this).parent().find('.image_path').val();
                        images.push(path);
                    });

                    $.ajax({
                        url: &quot;http://jom-demo-banda.stagingapps.net/finishing/category/regular-print/instant/retail&quot;,
                        type: &quot;POST&quot;,
                        data:{
                            images: images,
                        },
                        success: function(data){
                             $(document).find('.printing_photos:checked').parent().parent().parent().parent().fadeOut(&quot;slow&quot;);
                             $(document).find('.printing_photos:checked').remove();
                             $(document).find('.printing_photos:checked').removeAttr('checked');
                             $('#checkboxAll').removeAttr('checked');
                             getCheckedPhotos();
                        }
                    });
                }
            }else{
                $(&quot;.alert&quot;).html(&quot;Belum ada foto yang dipilih&quot;).show();
                  setTimeout(function(){$(&quot;.alert&quot;).hide();}, 3000);
            }

        });

        function getCheckedPhotos(){
            var checkedPhotos = 0;

            $(document).find('.printing_photos:checked').each(function(){
                checkedPhotos++;
            });

            if(checkedPhotos > 0){
                $('.print-button').removeAttr('disabled');
                $('.remove-printing').attr('disabled', true);
            }else{
                $('.print-button').attr('disabled', true);
            }

            $('.selected_photos').html(checkedPhotos);
        }
    
    
        var notifElem = '#notification-container';

        $(document).on('click', '.printing-qty button', function() {
            calculateSubtotal();
        });

        $(document).on('change', '#qty', function() {
           calculateSubtotal();
        });

        $(document).on('click', '.remove-printing', function() {
            $('#modal-add-print-container').show();
            $('#modal-add-print-container .button-add-print').html('+ Tambah Cetakan');
            $('#product').hide();
            $('#product').html();
            $('#frame-display').html('+');
            $('#frame-display').removeClass('sold-type-package');
            $('#f_item_code').val('');
            $('#f_name').val('');
            $('#f_image').val('');
            $('#f_price').val('0');
            $('#sold-type').val('');
            $('#price').val('');
            $('#price_amount').val('');
            $('#original_price').val('');
            $('#paper_type').html('&lt;option value=&quot;&quot;>Kertas&lt;/option>');
            $('#paper_type').material_select();
            $('#total-price').val('');
            $('#qty').val('1');
            $('#item_code').val('');
            $('#item_type').val('');
            $('#product-id').val('');
            var $color_select = $('#color');
            $('#color').material_select('destroy');
            $('#color').html('&lt;option value=&quot;&quot;>Warna&lt;/option>');
            $('#color').material_select();
            $('span.caret').remove();
            $('.btn-print-same-size').attr('disabled', true);
            $('.remove-printing').attr('disabled', true);
            make_enable_or_disable();
        });

        $(document).on('click', '.submit-custom-product', function(e){
            var products = {};
            $(document).find('.printing_photos:checked').each(function(index ){
                                    products[index] = {
                        image : $(this).parent().find('.image_path').val(),
                        product_image : 'uploads/product_printing/15304354250Action 8 Kids 500x500.jpg',
                        name :  'Copy Paket Studio Action 8 &amp; 10',
                        item_code : '999001000122',
                        item_type : '3',
                        paper_type : 'Photo',
                        paper_type_id : '2',
                        color : '2',
                        price : '0',
                        qty : '1',
                        subtotal : '0'
                    };
                            });

            $.ajax({
                url: 'http://jom-demo-banda.stagingapps.net/finishing/category/regular-print/instant/retail/submit-order',
                type: &quot;POST&quot;,
                dataType: &quot;json&quot;,
                data: {
                    products : products,
                    status : 'custom_product'
                },
                beforeSend: function(){
                    $('#print-choiceproduct').modal('hide');
                    $(document).find('body').removeClass('loaded');
                },
                success: function(response){
                    window.location.href = response.redirect;
                },
                error: function(response){
                    $(document).find('body').addClass('loaded');
                }
            });

            return false;
        });

        $(document).on('click', '.submit-same-product', function(e){
            var products = {};
            $(document).find('.printing_photos:checked').each(function(index ){
                var amount = $(document).find('#total-price').val();
                var sanitize = amount.replace(/[^0-9]/g, '')
                products[index] = {
                    image : $(this).parent().find('.image_path').val(),
                    product_id : $(document).find('#product-id').val(),
                    product_image : $(document).find('#image').val(),
                    name :  $(document).find('#product').text(),
                    item_code : $(document).find('#item_code').val(),
                    item_type : $(document).find('#item_type').val(),
                    paper_type : $(document).find('#paper_type').text(),
                    paper_type_id : $(document).find('#paper_type').val(),
                    color : $(document).find('#color').val(),
                    sold_type : $(document).find('#sold-type').val(),
                    frame : $(document).find('#frame-display img').attr('src'),
                    frame_item_code : $(document).find('#f_item_code').val(),
                    frame_name : $(document).find('#f_name').val(),
                    frame_image : $(document).find('#f_image').val(),
                    frame_price : $(document).find('#f_price').val(),
                    original_price : $(document).find('#original_price').val(),
                    total_discount : $(document).find('#total_discount').val(),
                    price_discount : $(document).find('#price_discount').val(),
                    discount_percent : $(document).find('#discount_percent').val(),
                    price : $(document).find('#price_discount').val(),
                    qty : $(document).find('#qty').val(),
                    subtotal : sanitize
                };
            });


            $.ajax({
                url: 'http://jom-demo-banda.stagingapps.net/finishing/category/regular-print/instant/retail/submit-order',
                type: &quot;POST&quot;,
                dataType: &quot;json&quot;,
                data: {
                    products : products,
                    status : 'same_product'
                },
                beforeSend: function(){
                    $('#print-choiceproduct').modal('hide');
                    $(document).find('body').removeClass('loaded');
                },
                success: function(response){
                    window.location.href = response.redirect;
                },
                error: function(response){
                    $(document).find('body').addClass('loaded');
                }
            });

            return false;
        });

        function calculateSubtotal(){
            var qty        = $('#qty').val();
            var price      = $('#price_amount').val();
            var subtotal   = (parseInt(price) * parseInt(qty));
            var product_id = $(document).find('#product-id').val();
            var item_code  = $(document).find('#item_code').val();
            var name       = $(document).find('#product').text();
            var original_price = $(document).find('#original_price').val();

            $.ajax({
                url: 'http://jom-demo-banda.stagingapps.net/finishing/get-promo',
                type: &quot;GET&quot;,
                dataType: &quot;JSON&quot;,
                data: {
                    item_id   : product_id,
                    item_code : item_code,
                    item_qty  : qty,
                    item_type : 3,
                    item_price: original_price,
                    name      : name
                },
                success: function(response){
                    var data = response.data;
                    var status = response.status;
                    if (status == 200) {

                        var discount = parseInt(original_price) - (parseInt(original_price) * parseInt(data.item_discount) / 100);
                        var subtotal = (discount) * parseInt(qty);
                        var total_discount = parseInt(qty) * (parseInt(original_price) * parseInt(data.item_discount) / 100);
                        $('#price').val(discount);
                        $('#price_discount').val(discount);
                        $('#discount_percent').val(parseInt(data.item_discount));
                        $('#total_discount').val(parseInt(total_discount));
                        $('#price_amount').val(subtotal);
                        inputMask('#price');
                    }else{
                        $('#price_discount').val(0);
                        $('#discount_percent').val(0);
                        $('#total_discount').val(0);
                        $('#price').val(original_price);
                        subtotal   = (parseInt(original_price) * parseInt(qty));
                        $('#price_amount').val(subtotal);
                        inputMask('#price');
                    }

                    $('#total-price').val(subtotal);
                    inputMask('#total-price');
                }
            });
        }

        function inputMask(element){
            $(element).inputmask(&quot;numeric&quot;, {
                radixPoint: &quot;,&quot;,
                groupSeparator: &quot;.&quot;,
                digits: 2,
                allowMinus : false,
                autoGroup: true,
                prefix: 'Rp ',
                rightAlign: false,
                oncleared: function () {
                    if(self.Value){
                        self.Value('');
                    }
                }
            });
        }
    
    
        $(document).on('show.bs.modal','#modal-add-print', function () {

            $('.tab-product [type=&quot;checkbox&quot;]').each(function(i, obj) {
                $(this).prop('checked' , false);
            });
            
        })
        $(document).on('click', '.product-radio', function(){
            $('.submit-product').removeAttr('disabled');
            $('.remove-printing').attr('disabled', false);
        });
            
        $('.relative .caret').remove();
    



$(function(){
    $(document).ready(function() {
        $(&quot;.toggle-password&quot;).click(function() {
            $(this).toggleClass(&quot;fa-eye fa-eye-slash&quot;);
            var input = $('input[name='+$(this).attr(&quot;flag-input&quot;)+']');
            if (input.attr(&quot;type&quot;) == &quot;password&quot;) {
              input.attr(&quot;type&quot;, &quot;text&quot;);
            } else {
              input.attr(&quot;type&quot;, &quot;password&quot;);
            }
        });
    });
    /*End tour everytime click a link*/
    $(document).on('click', 'a', function(){
        var exception_ids = ['start-tour', 'tour-product-3', 'tour-product-4'];
        var exception_classes = 'carousel-control';
        if($.inArray($(this).attr('id'), exception_ids) == -1){
            if($(this).is(exception_classes)){
                tour.end();
            }
        }
    });

    /*End tour everytime click a submit button*/
    $(document).on('click', 'button[type=&quot;submit&quot;]', function(){
        var exceptions = [];
        if($.inArray($(this).attr('id'), exceptions) == -1) tour.end();
    });

    $(document).on('click', '.btn-submit', function(){
        var exceptions = [];
        if($.inArray($(this).attr('id'), exceptions) == -1) tour.end();
    });

    $(document).on('shown.bs.modal', '.modal', function(){
        tour.end();
    });

    /*Preloader*/
    $(window).load(function() {
        setTimeout(function() {
            $('body').addClass('loaded');
        }, 300);
    });

    $(window).bind('beforeunload', function() {
        setTimeout(function() {
            $('body').removeClass('loaded');
        }, 300);
    });

    // action modal form login
    $(document).on('click', '#modal-login #modal-tab-login-submit', function(e){
        var username = $(document).find('input[name=username]').val();
        var password = $(document).find('input[name=password]').val();
        var form = $(this).parents('form');
        $.ajax({
            url: $(form).attr('action'),
            type: &quot;POST&quot;,
            dataType: &quot;JSON&quot;,
            data: $(form).serialize(),
            beforeSend: function(){
                if(username == '' &amp;&amp; password == ''){
                    $(form).find('#username').addClass('error');
                    $(form).find('label[for=username]').attr('data-error', 'Username is required');
                    $(form).find('#password').addClass('error');
                    $(form).find('label[for=password]').attr('data-error', 'Password is required');
                }else if(username == ''){
                    $(form).find('#username').addClass('error');
                    $(form).find('label[for=username]').attr('data-error', 'Username is required');
                }else if(password == ''){
                    $(form).find('#password').addClass('error');
                    $(form).find('label[for=password]').attr('data-error', 'Password is required');
                }else{
                    setTimeout(() => {
                        $('#modal-login').modal('hide');
                        $(document).find('body').removeClass('loaded');
                    }, 500);
                }
            },
            success: function(response){
                if (response.meta.status==200) {
                    $('#modal-login').modal('hide');
                    window.location.href = response.redirect;
                } else {
                    $(document).find('body').addClass('loaded');
                    $('#modal-login').modal('show');
                    $(form).find('input[type=&quot;password&quot;]').val('');
                    $(form).find('input').removeClass('error').removeClass('valid');
                    $(form).find('label').attr('data-error','').attr('data-success', '');
                    if (response.data.message!=undefined) {
                        $(form).find('#username').addClass('error');
                        $(form).find('label[for=username]').attr('data-error', response.data.message);
                    }
                }
            }
        });
        e.preventDefault();
    });

    // information password Low to Very Strong when typing password in modal form register
    $(document).on('keyup', '#modal-login #modal-tab-register #password', function(e){
        var string = $(this).val();
        App.password_information(string, this);
    });

    // action go to modal form login
    $(document).on('click', '#modal-login #modal-tab-register-login', function(e){
        $('#modal-btn-tab-login a').tab('show');
    });

    // action modal form register
    $(document).on('click', '#modal-login #modal-tab-register-submit', function(e){
        var form = $(this).parents('form');
        $.ajax({
            url: $(form).attr('action'),
            type: &quot;POST&quot;,
            dataType: &quot;JSON&quot;,
            data: $(form).serialize(),
            success: function(response){
                if(response.status == 404){
                    var element = '&lt;ul class=&quot;alert alert-danger&quot; style=&quot;list-style: none;&quot;>&lt;li>'+response.message+'&lt;/li>&lt;/ul>';
                    $('.error-description').html(element);
                }
                if (response.meta.status==200) {
                    window.location.href = response.redirect;
                } else {
                    $(form).find('input[type=&quot;password&quot;]').val('');
                    $(form).find('input').removeClass('error').removeClass('valid');
                    $(form).find('label').attr('data-error','').attr('data-success', '');
                    if (response.data.email!=undefined) {
                        $(form).find('#email').addClass('error');
                        $(form).find('label[for=email]').attr('data-error', response.data.email[0]);
                    }
                    if (response.data.phone!=undefined) {
                        $(form).find('#phone').addClass('error');
                        $(form).find('label[for=phone]').attr('data-error', response.data.phone[0]);
                    }
                    if (response.data.password!=undefined) {
                        $(form).find('#password').addClass('error');
                        $(form).find('label[for=password]').attr('data-error', response.data.password[0]);
                    }
                }
            }
        });
        e.preventDefault();
    });

    // always show modal form completed register when name user is null
    
    // action change selectbox province
    $(document).on('change', '#modal-register #province, #modal-add-address #province, #modal-edit-address #province, #edit-profile #province', function(){
        var select_city = $(this).parents('form').find('#city');
        $.ajax({
            url: &quot;http://jom-demo-banda.stagingapps.net/ajax/city&quot;,
            dataType: &quot;json&quot;,
            data: {'province_id': $(this).val()},
            success: function(response){
                $(select_city).val('');
                $(select_city).find('option:not(:first)').remove();
                for (var i = 0; i &lt; response.data.length; i++) {
                    $(select_city).append('&lt;option value=&quot;'+response.data[i].id+'&quot;>'+response.data[i].name+'&lt;/option>');
                }
                $(select_city).material_select('destroy');
                $(select_city).material_select();
            }
        });
    });

    // action change selectbox city
    $(document).on('change', '#modal-register #city, #modal-add-address #city, #modal-edit-address #city, #edit-profile #city', function(){
        var select_district = $(this).parents('form').find('#district');
        $.ajax({
            url: &quot;http://jom-demo-banda.stagingapps.net/ajax/district&quot;,
            dataType: &quot;json&quot;,
            data: {'city_id': $(this).val()},
            success: function(response){
                $(select_district).val('');
                $(select_district).find('option:not(:first)').remove();
                for (var i = 0; i &lt; response.data.length; i++) {
                    $(select_district).append('&lt;option value=&quot;'+response.data[i].id+'&quot;>'+response.data[i].name+'&lt;/option>');
                }
                $(select_district).material_select('destroy');
                $(select_district).material_select();
            }
        });
    });

    // action modal form completed register
    $(document).on('click', '#modal-register #modal-register-submit', function(e){
        var form = $(this).parents('form');
        $.ajax({
            url: $(form).attr('action'),
            type: &quot;PUT&quot;,
            dataType: &quot;JSON&quot;,
            data: $(form).serialize(),
            success: function(response){
                if (response.meta.status==200) {
                    window.location.href = response.redirect;
                } else {
                    $(form).find('input,select').removeClass('error').removeClass('valid');
                    $(form).find('label').attr('data-error','').attr('data-success', '');
                    if (response.data.name!=undefined) {
                        $(form).find('#name').addClass('error');
                        $(form).find('label[for=name]').attr('data-error', response.data.name[0]);
                    }
                    if (response.data.birth_date!=undefined) {
                        $(form).find('.birth_date').addClass('error');
                        $(form).find('label[for=birth_date]').attr('data-error', response.data.birth_date[0]);
                    }
                    if (response.data.gender!=undefined) {
                        $(form).find('.gender').addClass('error');
                        $(form).find('label[for=gender]').attr('data-error', response.data.gender[0]);
                    }
                    if (response.data.province!=undefined) {
                        $(form).find('#province').addClass('error');
                        $(form).find('label[for=province]').attr('data-error', response.data.province[0]);
                    }
                    if (response.data.city!=undefined) {
                        $(form).find('#city').addClass('error');
                        $(form).find('label[for=city]').attr('data-error', response.data.city[0]);
                    }
                    if (response.data.district!=undefined) {
                        $(form).find('#district').addClass('error');
                        $(form).find('label[for=district]').attr('data-error', response.data.district[0]);
                    }
                    if (response.data.address!=undefined) {
                        $(form).find('#address').addClass('error');
                        $(form).find('label[for=address]').attr('data-error', response.data.address[0]);
                    }
                }
            }
        });
        e.preventDefault();
    });

    $(document).on('click', '.goto-forgot-password', function(e){
        $(this).parents('.modal').modal('hide');
        $('#modal-forgot-password').modal('show');
        e.preventDefault();
    });

    $(document).on('click', '#modal-forgot-password button[type=submit]', function(e){
        var form = $(this).parents('form');
        $.ajax({
            url: $(form).attr('action'),
            type: &quot;POST&quot;,
            dataType: &quot;JSON&quot;,
            data: $(form).serialize(),
            success: function(response){
                if (response.meta.status==200) {
                    window.location.href = response.redirect;
                } else {
                    $(form).find('input').removeClass('error').removeClass('valid');
                    $(form).find('label').attr('data-error','').attr('data-success', '');
                    if (response.data.email!=undefined) {
                        $(form).find('#email').addClass('error');
                        $(form).find('label[for=email]').attr('data-error', response.data.email[0]);
                    }
                }
            }
        });
        e.preventDefault();
    });

    
    $(document).on('keyup', '#modal-reset-password #password', function(e){
        var string = $(this).val();
        App.password_information(string, this);
    });

    $(document).on('click', '#modal-reset-password button[type=submit]', function(e){
        var form = $(this).parents('form');
        $.ajax({
            url: $(form).attr('action'),
            type: &quot;POST&quot;,
            dataType: &quot;JSON&quot;,
            data: $(form).serialize(),
            success: function(response){
                if (response.meta.status==200) {
                    window.location.href = response.redirect;
                } else {
                    $(form).find('input').removeClass('error').removeClass('valid');
                    $(form).find('label').attr('data-error','').attr('data-success', '');
                    if (response.data.email!=undefined) {
                        $(form).find('#email').addClass('error');
                        $(form).find('label[for=email]').attr('data-error', response.data.email[0]);
                    }
                    if (response.data.password!=undefined) {
                        $(form).find('#password').addClass('error');
                        $(form).find('label[for=password]').attr('data-error', response.data.password[0]);
                    }
                }
            }
        });
        e.preventDefault();
    });

    $(document).on('click', '#modal-choiceproduct .remove-cart-studio', function(){
        var url = $(this).data('url');
        var tr = $(this).parents('tr');
        $.ajax({
            url: url,
            type: &quot;GET&quot;,
            dataType: &quot;JSON&quot;,
            success: function(response){
                var tbody = $('#modal-choiceproduct tbody');
                if ($(tbody).find('tr').not('.transparent').length == 1) {
                    html = '&lt;tr>';
                    html += '&lt;td colspan=&quot;6&quot;>&lt;h5 class=&quot;text-center&quot;>Keranjang belanja anda kosong&lt;/h5>&lt;/td>';
                    html += '&lt;/tr>';
                    $(tbody).prepend(html);
                }
                $(tr).remove();
                $('.cart-total-product-studio').text(response.cart_total_product_studio);
                $('.cart-total-price-studio').text(response.cart_total_price_studio);

                if(response.cart_total_product_studio==0) {
                    $(document).find('a.goto-checkout-studio').remove();
                    $(document).find('.cart-checkout-studio').append('&lt;button class=&quot;waves-effect waves-light btn-submit btn-gold-effect goto-checkout-studio&quot; disabled>Selesai, Lanjutkan ke Order &lt;i class=&quot;fa fa-angle-right&quot; aria-hidden=&quot;true&quot;>&lt;/i>&lt;/button>');
                    reloadPage();
                }else{
                    $(document).find('.goto-checkout-studio').remove();
                    $(document).find('.cart-checkout-studio').append('&lt;a href=&quot;javascript:void(0);&quot; class=&quot;waves-effect waves-light btn-submit btn-gold-effect goto-checkout-printing-package btn-next&quot; id=&quot;modal_group&quot;>Selesai, Lanjutkan ke Order &lt;i class=&quot;fa fa-angle-right&quot; aria-hidden=&quot;true&quot;>&lt;/i>&lt;/a>');
                }
            }
        });
    });

    $(document).on('click', '#modal-choiceprinting .remove-cart-printing', function(){
        var url = $(this).data('url');
        var tr = $(this).parents('tr');
        $.ajax({
            url: url,
            type: &quot;GET&quot;,
            dataType: &quot;JSON&quot;,
            success: function(response){
                var tbody = $('#modal-choiceprinting tbody');
                if ($(tbody).find('tr').not('.transparent').length == 1) {
                    html = '&lt;tr>';
                    html += '&lt;td colspan=&quot;6&quot;>&lt;h5 class=&quot;text-center&quot;>Keranjang belanja anda kosong&lt;/h5>&lt;/td>';
                    html += '&lt;/tr>';
                    $(tbody).prepend(html);
                }
                $(tr).remove();
                $('.cart-total-product-printing').text(response.cart_total_product_printing);
                $('.cart-total-price-printing').text(response.cart_total_price_printing);

                if (response.cart_total_product_printing==0) {
                    $(document).find('a.goto-checkout-printing').remove();
                    $(document).find('.cart-checkout-printing').append('&lt;button class=&quot;waves-effect waves-light btn-submit btn-gold-effect goto-checkout-printing&quot; disabled>Selesai, Lanjutkan ke Order &lt;i class=&quot;fa fa-angle-right&quot; aria-hidden=&quot;true&quot;>&lt;/i>&lt;/button>');
                    reloadPage();
                }//else{
                //     $(document).find('.goto-checkout-printing').remove();
                //     $(document).find('.cart-checkout-printing').append('&lt;a class=&quot;waves-effect waves-light btn-submit btn-gold-effect goto-checkout-printing btn-next&quot; id=&quot;modal_group&quot;>Selesai, Lanjutkan ke Order &lt;i class=&quot;fa fa-angle-right&quot; aria-hidden=&quot;true&quot;>&lt;/i>&lt;/a>');
                // } commented for task-502
            }
        });
    });

    $(document).on('click', '#modal-choiceproduct .change-qty-cart-studio', function(){
        changeQtyCartStudio($(this));
    });

    $(document).on('keyup', '#modal-choiceproduct .change-qty-cart-studio', function(){
        setTimeout(() => {
            if($(this).val() != '' || $(this).val() > 0){
                setTimeout(() => {
                    changeQtyCartStudio($(this));
                }, 500);
            }else if($(this).val() == 0){
                $(this).val(1);
                setTimeout(() => {
                    changeQtyCartStudio($(this));
                }, 500);
            }
        }, 1000);
    });

    function reloadPage(){
        setTimeout(() => {
            window.location.reload();
        }, 3000);
    }

    function changeQtyCartStudio(element){
        var url = element.data('url');
        var id = element.data('id');
        $.ajax({
            url: url,
            type: &quot;POST&quot;,
            dataType: &quot;JSON&quot;,
            data: {
                _token: &quot;Bx2HCRsvjKxckHcquC1OIWD5XbOvfzYrdjWQLyR0&quot;,
                qty: element.parents('td').find('input[type=number]').val(),
            },
            success: function(response){
                $('.cart-total-product-studio').text(response.cart_total_product_studio);
                $('.cart-total-price-studio').text(response.cart_total_price_studio);
                $('.cart-subtotal-price-studio-'+id).text(response.cart_subtotal_price_studio);
            }
        });
    }

    $(document).on('click', '#modal-choiceprinting .change-qty-cart-printing', function(){
        changeQtyCartPrinting($(this));
    });

    $(document).on('keyup', '#modal-choiceproduct .change-qty-cart-printing', function(){
        setTimeout(() => {
            if($(this).val() != '' || $(this).val() > 0){
                setTimeout(() => {
                    changeQtyCartPrinting($(this));
                }, 500);
            }else if($(this).val() == 0){
                $(this).val(1);
                setTimeout(() => {
                    changeQtyCartPrinting($(this));
                }, 500);
            }
        }, 1000);
    });

    function changeQtyCartPrinting(element)
    {
        var url = element.data('url');
        var id = element.data('id');
        $.ajax({
            url: url,
            type: &quot;POST&quot;,
            dataType: &quot;JSON&quot;,
            data: {
                _token: &quot;Bx2HCRsvjKxckHcquC1OIWD5XbOvfzYrdjWQLyR0&quot;,
                qty: element.parents('td').find('input[type=number]').val(),
            },
            success: function(response){
                $('.cart-total-product-printing').text(response.cart_total_product_printing);
                $('.cart-total-price-printing').text(response.cart_total_price_printing);
                $('.cart-subtotal-price-printing-'+id).text(response.cart_subtotal_price_printing);
            }
        });
    }

    $(document).on('click', '.change-qty-cart-printing-package', function(){
        changeQtyCartPackage($(this));
    });

    $(document).on('keyup', '#modal-choiceproduct .change-qty-cart-package', function(){
        setTimeout(() => {
            if($(this).val() != '' || $(this).val() > 0){
                setTimeout(() => {
                    changeQtyCartPackage($(this));
                }, 500);
            }else if($(this).val() == 0){
                $(this).val(1);
                setTimeout(() => {
                    changeQtyCartPackage($(this));
                }, 500);
            }
        }, 1000);
    });

    function changeQtyCartPackage(element){
        var url = element.data('url');
        var id = element.data('id');
        $.ajax({
            url: url,
            type: &quot;POST&quot;,
            dataType: &quot;JSON&quot;,
            data: {
                _token: &quot;Bx2HCRsvjKxckHcquC1OIWD5XbOvfzYrdjWQLyR0&quot;,
                qty: element.parents('td').find('input[type=number]').val(),
            },
            success: function(response){
                $('.cart-total-product-printing-package').text(response.cart_total_product_printing_package);
                $('.cart-total-price-printing-package').text(response.cart_total_price_printing_package);
                $('.cart-subtotal-price-printing-package-'+id).text(response.cart_subtotal_price_printing_package);
            }
        });
    }

    $(document).on('click', '#modal-choice-printing-package .remove-cart-printing-package', function(){
        var url = $(this).data('url');
        var tr = $(this).parents('tr');
        $.ajax({
            url: url,
            type: &quot;GET&quot;,
            dataType: &quot;JSON&quot;,
            success: function(response){
                var tbody = $('#modal-choice-printing-package tbody');
                if ($(tbody).find('tr').not('.transparent').length == 1) {
                    html = '&lt;tr>';
                    html += '&lt;td colspan=&quot;6&quot;>&lt;h5 class=&quot;text-center&quot;>Keranjang belanja anda kosong&lt;/h5>&lt;/td>';
                    html += '&lt;/tr>';
                    $(tbody).prepend(html);
                }
                $(tr).remove();
                $('.cart-total-printing-package').text(response.cart_total_printing_package);
                $('.cart-total-product-printing-package').text(response.cart_total_printing_package);
                $('.cart-total-price-printing-package').text(response.cart_total_price_printing_package);

                if(response.cart_total_printing_package==0) {
                    $(document).find('a.goto-checkout-printing-package').remove();
                    $(document).find('.cart-checkout-printing-package').append('&lt;button class=&quot;waves-effect waves-light btn-submit btn-gold-effect goto-checkout-printing-package&quot; disabled>Selesai, Lanjutkan ke Order &lt;i class=&quot;fa fa-angle-right&quot; aria-hidden=&quot;true&quot;>&lt;/i>&lt;/button>');
                    reloadPage();
                }//else{
                    // $(document).find('.goto-checkout-printing-package').remove();
                    // $(document).find('.cart-checkout-printing-package').append('&lt;a class=&quot;waves-effect waves-light btn-submit btn-gold-effect goto-checkout-printing-package btn-next&quot; id=&quot;modal_group&quot;>Selesai, Lanjutkan ke Order &lt;i class=&quot;fa fa-angle-right&quot; aria-hidden=&quot;true&quot;>&lt;/i>&lt;/a>');
                // } commented for task-502
            }
        });
    });

    $(document).on('click', '#modal-choice-printing-package .change-qty-cart-studio', function(){
        var url = $(this).data('url');
        var id = $(this).data('id');
        $.ajax({
            url: url,
            type: &quot;POST&quot;,
            dataType: &quot;JSON&quot;,
            data: {
                _token: &quot;Bx2HCRsvjKxckHcquC1OIWD5XbOvfzYrdjWQLyR0&quot;,
                qty: $(this).parents('td').find('input[type=number]').val(),
            },
            success: function(response){
                $('.cart-total-printing-package').text(response.cart_total_printing_package);
                $('.cart-total-price-printing-package').text(response.cart_total_price_printing_package);
                $('.cart-subtotal-price-printing-package-'+id).text(response.cart_subtotal_price_printing_package);
            }
        });
    });
    if($('input[name=&quot;_token&quot;]').length){
        $.ajaxSetup({
            headers: {
                'X-CSRF-Token': $('input[name=&quot;_token&quot;]').val()
            }
        });
    }

    $('input[type=&quot;number&quot;]').keydown(function (e) {
        // Allow: backspace, delete, tab, escape, enter and .
        if ($.inArray(e.keyCode, [46, 8, 9, 27, 13, 110, 190, 39]) !== -1 ||
             // Allow: Ctrl+A, Command+A
            (e.keyCode === 65 &amp;&amp; (e.ctrlKey === true || e.metaKey === true)) ||
             // Allow: home, end, left, right, down, up
            (e.keyCode >= 35 &amp;&amp; e.keyCode &lt;= 37)) {
                 // let it happen, don't do anything
                 return;

        }

        // Ensure that it is a number and stop the keypress
        if ((e.shiftKey || (e.keyCode &lt; 48 || e.keyCode > 57)) &amp;&amp; (e.keyCode &lt; 96 || e.keyCode > 105)) {
            e.preventDefault();
        }
    });

    $('#flash-overlay-modal').modal('show');
    $('#alert-flash-notification').not('.alert-important').delay(1000).slideDown(1000).delay(5000).slideUp(1000);
    $('#alert-flash-notification.alert-important').delay(1000).slideDown(1000);

    // action modal form pending
    $(document).on('click', '#modal-pending-submit', function(e){
        var form = $(this).parents('form');
        $.ajax({
            url: $(form).attr('action'),
            type: &quot;POST&quot;,
            dataType: &quot;JSON&quot;,
            data: $(form).serialize(),
            success: function(response){
                if (response.data.meta.status==200) {
                    window.location.href = response.redirect;
                } else {
                    $(form).find('input').removeClass('error').removeClass('valid');
                    $(form).find('label').attr('data-error','').attr('data-success', '');
                    if (response.data.data.reason!=undefined) {
                        $(form).find('#reason').addClass('error');
                        $(form).find('label[for=reason]').attr('data-error', response.data.data.reason[0]);
                    }
                    if (response.data.data.description!=undefined) {
                        $(form).find('#description').addClass('error');
                        $(form).find('label[for=description]').attr('data-error', response.data.data.description[0]);
                    }
                }
            }
        });
        e.preventDefault();
    });

});


$(document).on('keypress','.alphanumeric',function (e) {
   var regex = new RegExp(&quot;^[a-zA-Z0-9\b]+$&quot;);
            var str = String.fromCharCode(!e.charCode ? e.which : e.charCode);
            var allowedSpecialKeys = 'ArrowLeftArrowRightArrowUpArrowDownDeleteHomeEnd';
            var key = e.key;

            /*IE doesn't fire events for arrow keys, Firefox does*/
            if(allowedSpecialKeys.indexOf(key)>-1){
                return true;
            }

            if (regex.test(str)) {
                return true;
            }
            e.preventDefault();
            e.stopPropagation();
            e.cancelBubble = true;
            return false;
});
$(document).on('paste input propertychange','.alphanumeric',function (e) {
  $(this).val( $(this).val().replace(/[^a-zA-Z0-9\s]/gi, '').replace(/[_\s]/g, '') );
})

$(document).on('keypress','.alpha',function (e) {
   var regex = new RegExp(&quot;^[a-zA-Z\b]+$&quot;);
            var str = String.fromCharCode(!e.charCode ? e.which : e.charCode);
            var allowedSpecialKeys = 'ArrowLeftArrowRightArrowUpArrowDownDeleteHomeEnd';
            var key = e.key;

            /*IE doesn't fire events for arrow keys, Firefox does*/
            if(allowedSpecialKeys.indexOf(key)>-1){
                return true;
            }

            if (regex.test(str)) {
                return true;
            }
            e.preventDefault();
            e.stopPropagation();
            e.cancelBubble = true;
            return false;
});
$(document).on('paste input propertychange','.alpha',function (e) {
  $(this).val( $(this).val().replace(/[^a-z\s]/gi, '').replace(/[_\s]/g, '') );
})

$(document).on('keypress','.numeric',function (e) {
   var regex = new RegExp(&quot;^[0-9\b]+$&quot;);
            var str = String.fromCharCode(!e.charCode ? e.which : e.charCode);
            var allowedSpecialKeys = 'ArrowLeftArrowRightArrowUpArrowDownDeleteHomeEnd';
            var key = e.key;

            /*IE doesn't fire events for arrow keys, Firefox does*/
            if(allowedSpecialKeys.indexOf(key)>-1){
                return true;
            }

            if (regex.test(str)) {
                return true;
            }
            e.preventDefault();
            e.stopPropagation();
            e.cancelBubble = true;
            return false;
});

$(document).on('paste input propertychange','.numeric',function (e) {
  $(this).val( $(this).val().replace(/[^0-9\s]/gi, '').replace(/[_\s]/g, '') );
})

$(document).on('keyup','.uppercase',function (e) {
    this.value = this.value.toUpperCase();
});
$(document).on('keypress paste input propertychange','.hours',function (e) {
  if($(this).val() > 24){
    $(this).val('0');
  }
});
$(document).on('keypress paste input propertychange','.minutes',function (e) {
  if($(this).val() > 60){
    $(this).val('0');
  }
});

// $(document).ajaxStart(function(event,xhr,setting){
//     setTimeout(() => {
//         $(document).find('body').removeClass('loaded');
//     }, 1000);
// }).ajaxComplete(function(event,xhr,setting){
//     setTimeout(() => {
//         $(document).find('body').addClass('loaded');
//     }, 500);
// }).ajaxError(function(event,xhr,setting){
//     setTimeout(() => {
//         $(document).find('body').addClass('loaded');
//     }, 500);
// });


    
    
    
    
            var csrfToken = $('[name=&quot;csrf_token&quot;]').attr('content');

            setInterval(refreshToken, 3600000); // 1 hour 

            function refreshToken(){
                $.get('refresh-csrf').done(function(data){
                    csrfToken = data; // the new token
                });
            }

            setInterval(refreshToken, 3600000); // 1 hour 

    


id(&quot;print-choiceproduct&quot;)</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>/html[1]/body[@class=&quot;loaded modal-open&quot;]</value>
   </webElementProperties>
</WebElementEntity>
