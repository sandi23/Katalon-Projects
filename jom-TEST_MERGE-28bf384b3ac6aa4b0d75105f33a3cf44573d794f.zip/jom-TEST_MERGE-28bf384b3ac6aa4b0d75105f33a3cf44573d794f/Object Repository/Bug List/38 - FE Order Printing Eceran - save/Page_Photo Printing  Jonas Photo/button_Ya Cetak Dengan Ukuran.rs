<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>button_Ya Cetak Dengan Ukuran</name>
   <tag></tag>
   <elementGuidId>a5d92e9a-5487-4d1a-b069-e0d618e77a2a</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>button</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>type</name>
      <type>Main</type>
      <value>submit</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>waves-effect waves-light btn-submit btn-gold-effect btn-print-same-size m-40-auto submit-same-product</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>Ya, Cetak Dengan Ukuran Diatas</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;print-choiceproduct&quot;)/div[@class=&quot;modal-dialog large-modal&quot;]/div[@class=&quot;modal-content modal-notif-reg&quot;]/div[@class=&quot;modal-body no-padding clearfix&quot;]/form[@class=&quot;reg-form col-md-12 reservation-form-input uploaded-form-input m-40-auto&quot;]/div[@class=&quot;text-center&quot;]/button[@class=&quot;waves-effect waves-light btn-submit btn-gold-effect btn-print-same-size m-40-auto submit-same-product&quot;]</value>
   </webElementProperties>
</WebElementEntity>
