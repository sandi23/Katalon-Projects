<?xml version="1.0" encoding="UTF-8"?>
<WebElementEntity>
   <description></description>
   <name>div_Item InformationProduct Co</name>
   <tag></tag>
   <elementGuidId>bba04dc8-9a69-4871-b403-ac526b8206e9</elementGuidId>
   <selectorMethod>BASIC</selectorMethod>
   <useRalativeImagePath>false</useRalativeImagePath>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>tag</name>
      <type>Main</type>
      <value>div</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>class</name>
      <type>Main</type>
      <value>tab-content col-sm-12</value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>true</isSelected>
      <matchCondition>equals</matchCondition>
      <name>text</name>
      <type>Main</type>
      <value>
                                    Item InformationProduct CodeFG01 - FG-STUDIO PHOTOGRAPHYFamily CodeFG-104 - STUDIO BABIES &amp; KIDSItem Code999001000009Item DescriptionPh Std Mini Poster
General Information
    
        
            Status
            
                ActiveInactive
                            
        
        
            Product Studio Category 

            
                
                    
                                                                        
                                
                                                                    PSSC00002 - Casual
                                                                    PSSC00005 - Family
                                                                    PSSC00006 - Kids
                                                                    PSSC00007 - Group
                                                                    PSSC00008 - Studio Tempo Doeloe
                                                                    PSSC00009 - Pas Photo
                                                                    PSSC00036 - Product
                                                                    PSSC00050 - Instant Photo
                                                            
                                                    
                                
                                                                    PSSC00053 - Kategori Testing
                                                            
                                                            ×PSSC00006 - Kids

                            
        
        
        
            Product Studio Sub Category Group 

            
                
                    
                    
                                                                        Action Kids (30x60cm)
                                                    Action Kids (40x40cm)
                                                    Holly Jolly
                                                    Painting Kids
                                                    Mini Poster
                                                            ×Mini Poster

                            
        
    
     
    
        
            Name for Customer 
            
                
                            
        

        
            Weight (gram) 
            
                

                
                    
                
            
        
    

    
        
            Marketing Category 

            
                
                    
                                                                                                                                                                    
                                                                    Basic Studio Maternity
                                
                                                                                        
                                                                                                            
                                                                                                                                                
                                                                    TEST_DELETE_PRODUCT_SUBCATEGORY
                                
                                                                                        
                                                                                                            
                                                                                                                                                
                                                                    Studio Platinum
                                
                                                                                                                                Premium Gold
                                
                                                                                                                                Premium Silver
                                
                                                                                                                                Classic Gold
                                
                                                                                                                                Classic White
                                
                                                                                                                                Minimalis Black
                                
                                                                                                                                Minimalis White
                                
                                                                                                                                Penambahan Shots Paket Family
                                
                                                                                        
                                                                                                                                                
                                                                    Studio Group 8RP
                                
                                                                                                                                Studio Group 12RP
                                
                                                                                                                                Penambahan Shots Group
                                
                                                                                        
                                                                                                                                                
                                                                    Studio Action Kid
                                
                                                                                                                                Studio Painting Kid
                                
                                                                                                                                Studio Mini Poster
                                
                                                                                                                                Studio Holy Jolly
                                
                                                                                                                                Penambaham Shots Paket Kid
                                
                                                                                        
                                                                                                                                                
                                                                    Studio Pas Photo Umum
                                
                                                                                                                                Studio Pas Photo Custom
                                
                                                                                                                                Studio Pas Photo Retouch
                                
                                                                                                                                Studio Pas Photo For Success
                                
                                                                                        
                                                                                                                                                
                                                                    Penambahan Orang Photo Studio
                                
                                                                                        
                                                                                                                                                
                                                                    Studio On Location Group
                                
                                                                                        
                                                                                                                                                
                                                                    Studio On Location Graduation
                                
                                                                                        
                                                                                                                                                
                                                                    Studio On Location Corporate
                                
                                                                                        
                                                                                                                                                
                                                                    Studio On Location Pre&amp;Wedding
                                
                                                                                        
                                                                                                                                                
                                                                    Studio Tempo Doeloe Sajodo
                                
                                                                                                                                Studio Tempo Doeloe Sasarengan
                                
                                                                                                                                Studio Tempo Doeloe Ngariung
                                
                                                                                                                                Studio Tempo Doeloe Pra Panganten
                                
                                                                                                                                Penambahan Shots Studio Tempo Doeloe
                                
                                                                                        
                                                            ×Studio Mini Poster

                            
        
    

        
        
            Description
            
                
                            
        
    

    
        
            
            Image 
            
                
                
                


                
                

                
                            
        
    

    
        
            Package Type
            
                
                     Product Studio
                

                
                     Internal Package
                

                
                     Custom Package
                
                            
        
    

    
        
            Through the preview process ?
            
                
                     False
                
                  
                
                     True
                
                            
        
    

    
        
            Duration Photoshoot (Minute) 
            
                
                            
        

        
            Input Required 
            
                

                            
        

        
            Max Photoshoot 
            
                
                
                
                    
                
            
        
    

    
        
            Queue Type 

            
                
                                        
                    
                                                                        Casual I
                                                    Casual II
                                                    Family I
                                                    Family II
                                                    Family III
                                                    Family IV
                                                    Group I
                                                    Group II
                                                    Group III
                                                    Group IV
                                                    Instant Photo
                                                    Kids I
                                                    Kids II
                                                    Non Platinum Reservation
                                                    Pas Photo
                                                    Pas Photo For Success
                                                    Platinum Reservation
                                                    Product
                                                    Studio Tema Eropa
                                                    Studio Tema Sunda
                                                    Tema Eropa Reservation
                                                    Tema Sunda Reservation
                                                            ×Kids I

                            
        

        
            Total Person 
            
                

                
                    
                
            
        

        
            Total Pose 
            
                

                
                    
                
            
        
    

    

    $(function () {
      $(&quot;.upload-file&quot;).bind(&quot;change&quot;, function () {
          var fileUpload = $(&quot;.upload-file&quot;)[0];
          var regex = new RegExp(&quot;([a-zA-Z0-9\s_\\.\-:])+(.jpg|.png|.gif)$&quot;);
          if (regex.test(fileUpload.value.toLowerCase())) {
            if (typeof (fileUpload.files) != &quot;undefined&quot;) {
                var reader = new FileReader();
                reader.readAsDataURL(fileUpload.files[0]);
                reader.onload = function (e) {
                  var image = new Image();
                  image.src = e.target.result;
                    image.onload = function () {
                      var height = this.height;
                      var width = this.width;
                      var maximum = 500;
                        if (height > maximum || width > maximum) {
                          $(&quot;.alert-warning&quot;).html(&quot;Image is more than &quot;+maximum+&quot;x&quot;+maximum).show();
                          // $(&quot;html, body&quot;).animate({ scrollTop: 0 }, &quot;slow&quot;);
                          $(document).find('.upload-file').val(&quot;&quot;); 
                            setTimeout(function() 
                            {
                              $(&quot;.alert-warning&quot;).hide();
                            }, 3000);
                            return false;
                        } else if(height &lt; maximum || width &lt; maximum) {
                          $(&quot;.alert-warning&quot;).html(&quot;Low Resolution Image&quot;).show();
                          setTimeout(function() 
                          {
                            $(&quot;.alert-warning&quot;).hide();
                          }, 3000);
                          return true;
                        } else if(height == maximum &amp;&amp; width == maximum) {
                          $('.next').removeClass('hidden');
                          return true;
                        }
                    };
                }
            } else {
              alert(&quot;This browser does not support HTML5.&quot;);
                return false;
            }
          } else {
            alert(&quot;Please select a valid Image file.&quot;);
              return false;
          }
      });
    });
                  
                                    
    
        Default Background

        
            Default Background 

            
                
                    
                                                                        
                                
                                                                    Biru
                                                                    Default
                                                                    Kuning
                                                                    Merah
                                                                    Putih
                                                            
                                                            ×Default

                            
        
    

    
        
            
            Photoshoot Background
        

        
            
                Photoshoot Background 

                
                    
                                                                                    
                                    
                                                                            Biru
                                                                            Default
                                                                            Kuning
                                                                            Merah
                                                                            Putih
                                                                    
                                                                        

                                    
            

            
                Show at Order
                
                    
                         No
                    

                    
                         Yes
                    
                                    
            
        
    
    
    
        
            
            Editing Background
        

        
            
                Editing Background 

                
                    
                                                                                    
                                    
                                                                            Biru
                                                                            Default
                                                                            Kuning
                                                                            Merah
                                                                            Putih
                                                                    
                                                                        

                                    
            

            
                Show at Preview
                
                    
                         No
                    

                    
                         Yes
                    
                                    
            
        
    
                
                                    
    
        
            Template Type 

            
                
                    
                                                                        Collase
                                                    Single
                                                    Template Testing
                                                    Thematic
                                                            ×Collase

                            
        

        
            Total Box
            
                

                            
        

        
            
                                                            
                            
                                
                                Friendship FSP-01

                                                                    
                                                            
                        
                                            
                            
                                
                                Holly Jolly HJK-01

                                                                    
                                                            
                        
                                            
                            
                                
                                Holly Jolly HJK-02

                                                                    
                                                            
                        
                                            
                            
                                
                                Holly Jolly HJK-03

                                                                    
                                                            
                        
                                            
                            
                                
                                Holly Jolly HJK-04

                                                                    
                                                            
                        
                                            
                            
                                
                                Holly Jolly HJK-05

                                                                    
                                                            
                        
                                            
                            
                                
                                Mini Poster MP-07

                                                                    
                                                            
                        
                                            
                            
                                
                                Mini Poster MP-17

                                                                    
                                                            
                        
                                            
                            
                                
                                Mini Poster MP-19

                                                                    
                                                            
                        
                                            
                            
                                
                                Mini Poster MP-20

                                                                    
                                                            
                        
                                            
                            
                                
                                Mini Poster MP-21

                                                                    
                                                            
                        
                                            
                            
                                
                                Mini Poster MP-22

                                                                    
                                                            
                        
                                            
                            
                                
                                Rainbow RNB-04

                                                                    
                                                            
                        
                                            
                            
                                
                                Rainbow RNB-04

                                                                    
                                                            
                        
                                            
                            
                                
                                Rainbow RNB-04

                                                                    
                                                            
                        
                                            
                            
                                
                                Rainbow RNB-05

                                                                    
                                                            
                        
                                            
                            
                                
                                Rainbow RNB-05

                                                                    
                                                            
                        
                                            
                            
                                
                                Rainbow RNB-05

                                                                    
                                                            
                        
                                                
        
    

    
        Additional Template
        
            
                 No
            

            
                 Yes
            
                    
    

    
        
            
                                                            
                            
                                
                                Friendship FSP-01

                                                                    
                                                            
                        
                                            
                            
                                
                                Holly Jolly HJK-01

                                                                    
                                                            
                        
                                            
                            
                                
                                Holly Jolly HJK-02

                                                                    
                                                            
                        
                                            
                            
                                
                                Holly Jolly HJK-03

                                                                    
                                                            
                        
                                            
                            
                                
                                Holly Jolly HJK-04

                                                                    
                                                            
                        
                                            
                            
                                
                                Holly Jolly HJK-05

                                                                    
                                                            
                        
                                            
                            
                                
                                Mini Poster MP-07

                                                                    
                                                            
                        
                                            
                            
                                
                                Mini Poster MP-17

                                                                    
                                                            
                        
                                            
                            
                                
                                Mini Poster MP-19

                                                                    
                                                            
                        
                                            
                            
                                
                                Mini Poster MP-20

                                                                    
                                                            
                        
                                            
                            
                                
                                Mini Poster MP-21

                                                                    
                                                            
                        
                                            
                            
                                
                                Mini Poster MP-22

                                                                    
                                                            
                        
                                            
                            
                                
                                Rainbow RNB-04

                                                                    
                                                            
                        
                                            
                            
                                
                                Rainbow RNB-04

                                                                    
                                                            
                        
                                            
                            
                                
                                Rainbow RNB-04

                                                                    
                                                            
                        
                                            
                            
                                
                                Rainbow RNB-05

                                                                    
                                                            
                        
                                            
                            
                                
                                Rainbow RNB-05

                                                                    
                                                            
                        
                                            
                            
                                
                                Rainbow RNB-05

                                                                    
                                                            
                        
                                                
        
    
                
                                    
    
        
        
            Editing Point (Quota) 
            
                
            

                     

        
            Waiting Time 
            
            
                
                     Fix Time
                
                
                     Variable
                
            
            
        

        
            
                
            

            
                
            

            
                
            
        




        
            Production Process 
            
                
            

            
                
            

            
                
            

                     

        
            Photoshoot Point 
            
                
            

                     

        
            Min Shutter Count 
            
                
            

                     

        
            Max Shutter Count 
            
                
            

                     

        
            Priority 
            
                
                
                    0
                                            1
                                            2
                                            3
                                            4
                                            5
                                            6
                                            7
                                            8
                                            9
                                            10
                                    ×1
                
            

                     

    



    var waiting_time = $('input[name=&quot;waiting_timex&quot;]').val();
    $('input[name=&quot;waiting_time&quot;]').val(waiting_time);
    var priority = $( &quot;#priorityx option:selected&quot; ).val();
    $('input[name=&quot;priority&quot;]').val(priority);
                
                                    
    
        
            Preview Component at Front End Product

            
                
                    Component Preview 
                    
                        
                                                                                                Pose Terbaik
                                                                    Frame Berkualitas
                                                                    Reservation Available
                                                                    Elegan Triple Album
                                                                    Exclusive Album Platinum
                                                                    Exclusive Studio
                                                                    Imported Property
                                                                    Exclusive Frame
                                                                    Photo With Blok
                                                                    Good Calendar Design
                                                                    Cetak Photo 8RP
                                                                    Cetak Photo 12RP
                                                                    Photo Blok 12RP
                                                                    Photo Blok 8RP
                                                                    Cetak Photo 5R
                                                                    Cetak Photo 4R
                                                                    Mix : Information!
                                                                    Mix : Information!
                                                                    Termasuk CD
                                                                                    ××Pose Terbaik×Frame Berkualitas×Termasuk CD
                    
                
            
        

        
            Component at Finish Production (Finish Good List)
            
            
                Component 
                
                    
                
            

            
                    Qty 
                    
                        
                    
                
            

            
                 Add
            
            

            
                
                    
                        
                            
                                Name
                                Qty
                                Action
                            

                            

                                                                                                                                                        
                                                
                                                    1x Cetak Photo + Frame E03m Putih 12R
                                                    
                                                

                                                
                                                    1
                                                    
                                                

                                                
                                                    
                                                        
                                                    
                                                
                                            
                                                                                    
                                                
                                                    5x Cetak Photo 4R
                                                    
                                                

                                                
                                                    1
                                                    
                                                

                                                
                                                    
                                                        
                                                    
                                                
                                            
                                                                                    
                                                
                                                    1x CD + Amplop
                                                    
                                                

                                                
                                                    1
                                                    
                                                

                                                
                                                    
                                                        
                                                    
                                                
                                            
                                                                                                                                        
                        
                    
                
            
        

        
            Component for CP

            
                
                    Component 
                    
                        
                            
                                                                                                
                                                                                    999002000077 - Cetak Kanvas 24RP
                                                                                    999002000073 - Cetak Kanvas 20RP
                                                                                    999002000069 - Cetak Kanvas 16RP
                                                                                    999002000407 - Cetak Kanvas 80x120
                                                                                    999002000233 - XXXCetak Glossy + Lam 40x40cm
                                                                                    999002000244 - Cetak Photo + Laminasi 12RP
                                                                                    999002000243 - Cetak Photo + Laminasi 12R
                                                                                    999002000176 - Cetak Photo + Laminasi 16R
                                                                                    999002000177 - Cetak Photo + Laminasi 16RP
                                                                                    999002000178 - Cetak Photo + Laminasi 20R
                                                                                    999002000179 - Cetak Photo + Laminasi 20RP
                                                                                    999002000180 - Cetak Photo + Laminasi 24R
                                                                                    999002000246 - Cetak Photo + Laminasi 30x60cm
                                                                                    999002000245 - Cetak Photo + Laminasi 30x30cm
                                                                                    999002000241 - Cetak Photo + Laminasi 8R
                                                                                    999002000181 - Cetak Photo + Laminasi 24RP
                                                                                    999002000419 - Dummy Pembesaran
                                                                                    999002000046 - Cetak Photo 8R
                                                                                    999002000048 - Cetak Photo 8RP
                                                                                    999002000242 - Cetak Photo + Laminasi 8RP
                                                                                    999002000052 - Cetak Photo 12RP
                                                                            
                                                                    
                                                                                    999004000741 - Fr 80x120 Kla 852-1207 Tembaga  Linen
                                                                                    999004000245 - Fr 24RP Kla 852-1207 Tembaga  Linen
                                                                                    999004000205 - Fr 20RP Kla NSJ20 Gold Linen Gold
                                                                                    999004000250 - Fr 24RP Kla KF 53 Gold
                                                                                    999004000196 - Fr 20RP Kla KF 53 Gold
                                                                                    999004000150 - Fr 16RP Kla KF 53 Gold
                                                                                    999004000251 - Fr 24RP Kla KJ 54 Silver
                                                                                    999004000197 - Fr 20RP Kla KJ 54 Silver
                                                                                    999004000151 - Fr 16RP Kla KJ 54 Silver
                                                                                    999004000252 - Fr 24RP Kla KS4 Gold
                                                                                    999004000198 - Fr 20RP Kla KS4 Gold
                                                                                    999004000152 - Fr 16RP Kla KS4 Gold
                                                                                    999004000253 - Fr 24RP Kla KS4 Putih
                                                                                    999004000199 - Fr 20RP Kla KS4 Putih
                                                                                    999004000153 - Fr 16RP Kla KS4 Putih
                                                                                    999004000262 - Fr 24RP Min L060 Tebal Hitam
                                                                                    999004000263 - Fr 24RP Min L060 Tebal Putih
                                                                                    999004000217 - Fr 20RP Min L060 Hitam
                                                                                    999004000218 - Fr 20RP Min L060 Putih
                                                                                    999004000169 - Fr 16RP Min L023 Hitam
                                                                                    999004000170 - Fr 16RP Min L023 Putih
                                                                                    999004000049 - Fr 12R Min L023 Hitam
                                                                                    999004000051 - Fr 12R Min L023 Putih
                                                                                    999004000817 - Fr 8R Min E04P Hitam
                                                                                    999004000818 - Fr 8R Min E04P Putih
                                                                                    999004000041 - Fr 12R Min E04P Putih
                                                                                    999004000129 - Fr 16R Min E04P Putih
                                                                                    999004002151 - Fr 30x30 Min SB 01 ASH Natural
                                                                                    999004002149 - Fr 8RP Min E02PN Hijau
                                                                                    999004002148 - Fr 8RP Min E02PN Biru Tua
                                                                                    999004002150 - Fr 8RP Min E02PN Pink
                                                                                    999004002600 - Dummy Frame
                                                                                    999004000037 - Fr 12R Min E03M Putih
                                                                            
                                                                    
                                                                                    999004001094 - Blok OB 30x60 Putih (5207)
                                                                                    999004001107 - Blok OB 8RP Putih (5213)
                                                                                    999004001106 - Blok OB 8RP Hitam (5213)
                                                                                    999004001069 - Blok OB 12RP Putih (5213)
                                                                                    999004001068 - Blok OB 12RP Hitam (5213)
                                                                                    999004001075 - Blok OB 16RP Putih (5207)
                                                                                    999004001073 - Blok OB 16RP Hitam (5027)
                                                                                    999004001097 - Blok OB 40x40 Putih (5213)
                                                                            
                                                                    
                                                                                    999004001269 - Alb Susan 4R Triple Aloco Black Polos
                                                                                    999004001271 - Alb Susan 5R Triple Aloco Black Polos
                                                                                    999004001268 - Alb SS 8RP(20x30)6 BlckHCBHoriCvrPlsE009
                                                                                    999004001278 - Alb Susan 8RP 10 Blck E-HCB Hori E035
                                                                            
                                                                    
                                                                                    999002000277 - Cetak Pasfoto 4x6 (4) Instan
                                                                                    999002000042 - Cetak Photo 5R
                                                                                    999002000239 - Cetak Photo + Laminasi 5R
                                                                                    999002000275 - Cetak Pasfoto 2x3 (6) Instan
                                                                                    999002000276 - Cetak Pasfoto 3x4 (6) Instan
                                                                                    999002000418 - Dummy Cetak Kecil
                                                                                    999002000445 - Cetak Pasfoto Visa New Zealand Instan
                                                                                    999002000446 - Cetak Pasfoto Visa Australia Instan
                                                                                    999002000447 - Cetak Pasfoto Visa Vietnam Instan
                                                                                    999002000448 - Cetak Pasfoto Visa Thailand Instan
                                                                                    999002000449 - Cetak Pasfoto Visa Kamboja Instan
                                                                                    999002000450 - Cetak Pasfoto Visa Hongkong Instan
                                                                                    999002000451 - Cetak Pasfoto Visa Bangladesh Instan
                                                                                    999002000452 - Cetak Pasfoto Visa China Instan
                                                                                    999002000453 - Cetak Pasfoto Visa India Instan
                                                                                    999002000454 - Cetak Pasfoto Visa Korea Instan
                                                                                    999002000455 - Cetak Pasfoto Visa Mesir Instan
                                                                                    999002000456 - Cetak Pasfoto Visa Myanmar Instan
                                                                                    999002000457 - Cetak Pasfoto Visa Taiwan Instan
                                                                                    999002000458 - Cetak Pasfoto Visa Jepang Instan
                                                                                    999002000459 - Cetak Pasfoto Visa Schengen Instan
                                                                                    999002000460 - Cetak Pasfoto Visa Kanada Instan
                                                                                    999002000461 - Cetak Pasfoto Visa Rusia Instan
                                                                                    999002000462 - Cetak Pasfoto Visa USA Instan
                                                                                    999002000463 - Cetak Pasfoto Visa UK Instan
                                                                                    999002000464 - Cetak Pasfoto Visa Haji / Umroh Instan
                                                                                    999002000465 - Cetak Pasfoto Visa Israel Instan
                                                                                    999002000466 - Cetak Pasfoto Visa Dubai Instan
                                                                            
                                                                    
                                                                                    999002000038 - Cetak Photo 4R
                                                                            
                                                                    
                                                                                    999002000421 - Dummy Cetak Color
                                                                                    999002000422 - Dummy Cetak B&amp;W
                                                                            
                                                                    
                                                                                    999002000423 - Dummy Visa New Zealand
                                                                                    999002000424 - Dummy Visa Australia
                                                                                    999002000425 - Dummy Visa Vietnam
                                                                                    999002000426 - Dummy Visa Thailand
                                                                                    999002000427 - Dummy Visa Kamboja
                                                                                    999002000428 - Dummy Visa Hongkong
                                                                                    999002000429 - Dummy Visa Bangladesh
                                                                                    999002000430 - Dummy Visa China
                                                                                    999002000431 - Dummy Visa India
                                                                                    999002000432 - Dummy Visa Korea
                                                                                    999002000433 - Dummy Visa Mesir
                                                                                    999002000434 - Dummy Visa Myanmar
                                                                                    999002000435 - Dummy Visa Taiwan
                                                                                    999002000436 - Dummy Visa Jepang
                                                                                    999002000437 - Dummy Visa Schengen
                                                                                    999002000438 - Dummy Visa Kanada
                                                                                    999002000439 - Dummy Visa Rusia
                                                                                    999002000440 - Dummy Visa USA
                                                                                    999002000441 - Dummy Visa UK
                                                                                    999002000442 - Dummy Visa Haji / Umroh
                                                                                    999002000443 - Dummy Visa Israel
                                                                                    999002000444 - Dummy Visa Dubai
                                                                            
                                                                    
                                                                                    999007000002 - CD Jonas
                                                                                    999007000001 - Amplop CD
                                                                            
                                                                    
                                                                                    999002000467 - Dummy Cetak 8RP
                                                                                    999002000468 - Dummy Cetak 12RP
                                                                            
                                                                    
                                                                                    999004002617 - Dummy Blok Putih
                                                                                    999004002616 - Dummy Blok Hitam
                                                                                    999004002618 - Dummy Tanpa Blok
                                                                            
                                                                    
                                                                                    999001000181 - Dummy Pemotretan 7 Shoot
                                                                                    999001000182 - Dummy Pemotretan 8 Shoot
                                                                                    999001000183 - Dummy Pemotretan 9 Shoot
                                                                                    999001000184 - Dummy Pemotretan 10 Shoot
                                                                            
                                                                                    Component
                    
                
            

            
                
                    Qty 
                    
                        
                    
                


                
                    Text 
                    
                        
                            No
                        

                        
                             Yes
                        
                    
                
            
        

        
            Text

                            
                    Text 1
                    
                        
                            
                                                                                                Arial
                                                                    Arial Black
                                                                    Comic Sans
                                                                    Courier New
                                                                    Georgia
                                                                    Impact
                                                                    Lucida Console
                                                                    Lucida Sans Unicode
                                                                    Palatino
                                                                    Tahoma
                                                                    Times New Roman
                                                                    Trebuchet
                                                                    Verdana
                                                                                    Font
                    

                    
                        
                    

                    
                        
                    
                
                            
                    Text 2
                    
                        
                            
                                                                                                Arial
                                                                    Arial Black
                                                                    Comic Sans
                                                                    Courier New
                                                                    Georgia
                                                                    Impact
                                                                    Lucida Console
                                                                    Lucida Sans Unicode
                                                                    Palatino
                                                                    Tahoma
                                                                    Times New Roman
                                                                    Trebuchet
                                                                    Verdana
                                                                                    Font
                    

                    
                        
                    

                    
                        
                    
                
                            
                    Text 3
                    
                        
                            
                                                                                                Arial
                                                                    Arial Black
                                                                    Comic Sans
                                                                    Courier New
                                                                    Georgia
                                                                    Impact
                                                                    Lucida Console
                                                                    Lucida Sans Unicode
                                                                    Palatino
                                                                    Tahoma
                                                                    Times New Roman
                                                                    Trebuchet
                                                                    Verdana
                                                                                    Font
                    

                    
                        
                    

                    
                        
                    
                
                    
    

    
         Add
    
    

    
        
            
                
                    
                        Component
                        Qty
                        Text 1
                        Text 2
                        Text 3
                        Filter
                        Sequence
                        Show at Detail
                        Type
                        Name
                        Action
                    

                                                                                                        
                                    
                                        
                                             Group : Pembesaran
                                            
                                            
                                        
                                        
                                        
                                            
                                                YesNo
                                                
                                            
                                        
                                        
                                        
                                            
                                                
                                            
                                        
                                        
                                        
                                        
                                    
                                    
                                                                                                            
                                        
                                            999002000243 - Cetak Photo + Laminasi 12R
                                            
                                            
                                            
                                        
                                        
                                        
                                            1
                                            
                                        
                                        
                                        
                                            
                                                Tulis Teks Anda Disini
                                            
                                            
                                            
                                            
                                        
                                        
                                        
                                            
                                                
                                            
                                            
                                            
                                            
                                        
                                        
                                        
                                            
                                                
                                            
                                            
                                            
                                            
                                        
                                        
                                        
                                        
                                        
                                            
                                                
                                            
                                        
                                        
                                        
                                            
                                                YesNo
                                                
                                            
                                        
                                        
                                        
                                            
                                                
                                                    
                                                    Enlarge
                                                    Printing
                                                    Frame
                                                    Others
                                                ×Enlarge
                                            
                                        
                                        
                                        
                                            
                                                
                                            
                                        
                                        
                                        
                                            
                                                
                                            
                                        
                                    
                                                                                                        
                                                                                                                
                                    
                                        
                                             Group : Cetak
                                            
                                            
                                        
                                        
                                        
                                            
                                                YesNo
                                                
                                            
                                        
                                        
                                        
                                            
                                                
                                            
                                        
                                        
                                        
                                        
                                    
                                    
                                                                                                            
                                        
                                            999002000038 - Cetak Photo 4R
                                            
                                            
                                            
                                        
                                        
                                        
                                            5
                                            
                                        
                                        
                                        
                                            
                                                
                                            
                                            
                                            
                                            
                                        
                                        
                                        
                                            
                                                
                                            
                                            
                                            
                                            
                                        
                                        
                                        
                                            
                                                
                                            
                                            
                                            
                                            
                                        
                                        
                                        
                                        
                                        
                                            
                                                
                                            
                                        
                                        
                                        
                                            
                                                YesNo
                                                
                                            
                                        
                                        
                                        
                                            
                                                
                                                    
                                                    Enlarge
                                                    Printing
                                                    Frame
                                                    Others
                                                ×Printing
                                            
                                        
                                        
                                        
                                            
                                                
                                            
                                        
                                        
                                        
                                            
                                                
                                            
                                        
                                    
                                                                                                        
                                                                                                                
                                    
                                        
                                             Group : Frame
                                            
                                            
                                        
                                        
                                        
                                            
                                                YesNo
                                                
                                            
                                        
                                        
                                        
                                            
                                                
                                            
                                        
                                        
                                        
                                        
                                    
                                    
                                                                                                            
                                        
                                            999004000037 - Fr 12R Min E03M Putih
                                            
                                            
                                            
                                        
                                        
                                        
                                            1
                                            
                                        
                                        
                                        
                                            
                                                
                                            
                                            
                                            
                                            
                                        
                                        
                                        
                                            
                                                
                                            
                                            
                                            
                                            
                                        
                                        
                                        
                                            
                                                
                                            
                                            
                                            
                                            
                                        
                                        
                                        
                                        
                                        
                                            
                                                
                                            
                                        
                                        
                                        
                                            
                                                YesNo
                                                
                                            
                                        
                                        
                                        
                                            
                                                
                                                    
                                                    Enlarge
                                                    Printing
                                                    Frame
                                                    Others
                                                ×Frame
                                            
                                        
                                        
                                        
                                            
                                                
                                            
                                        
                                        
                                        
                                            
                                                
                                            
                                        
                                    
                                                                                                        
                                                                                                                
                                    
                                        
                                             Group : File Storage
                                            
                                            
                                        
                                        
                                        
                                            
                                                YesNo
                                                
                                            
                                        
                                        
                                        
                                            
                                                
                                            
                                        
                                        
                                        
                                        
                                    
                                    
                                                                                                            
                                        
                                            999007000002 - CD Jonas
                                            
                                            
                                            
                                        
                                        
                                        
                                            1
                                            
                                        
                                        
                                        
                                            
                                                
                                            
                                            
                                            
                                            
                                        
                                        
                                        
                                            
                                                
                                            
                                            
                                            
                                            
                                        
                                        
                                        
                                            
                                                
                                            
                                            
                                            
                                            
                                        
                                        
                                        
                                        
                                        
                                            
                                                
                                            
                                        
                                        
                                        
                                            
                                                YesNo
                                                
                                            
                                        
                                        
                                        
                                            
                                                
                                                    
                                                    Enlarge
                                                    Printing
                                                    Frame
                                                    Others
                                                ×Others
                                            
                                        
                                        
                                        
                                            
                                                
                                            
                                        
                                        
                                        
                                            
                                                
                                            
                                        
                                    
                                                                        
                                        
                                            999007000001 - Amplop CD
                                            
                                            
                                            
                                        
                                        
                                        
                                            1
                                            
                                        
                                        
                                        
                                            
                                                
                                            
                                            
                                            
                                            
                                        
                                        
                                        
                                            
                                                
                                            
                                            
                                            
                                            
                                        
                                        
                                        
                                            
                                                
                                            
                                            
                                            
                                            
                                        
                                        
                                        
                                        
                                        
                                            
                                                
                                            
                                        
                                        
                                        
                                            
                                                YesNo
                                                
                                            
                                        
                                        
                                        
                                            
                                                
                                                    
                                                    Enlarge
                                                    Printing
                                                    Frame
                                                    Others
                                                Type
                                            
                                        
                                        
                                        
                                            
                                                
                                            
                                        
                                        
                                        
                                            
                                                
                                            
                                        
                                    
                                                                                                        
                                                                                        
            

                    
    



    
        
            
                
                    
                
                Detail
            
            
                
                    
                        
                            
                                
                                    Component
                                    Qty
                                    Action
                                
                                    
                            
                        
                    
                
                
                    
                    
                        
                            Cancel
                        
                    
                
            
        
    
                
                                    
    
        
            Additional People 

            
                
                    
                                                                    999001000076 - Tambah Orang Ph Std Group 8RP
                                                999001000078 - Tambah Orang Ph Std Group 12RP
                                                999001000080 - Tambah orang Ph Std Group 8RP Mix
                                                999001000082 - Tambah Orang Ph Std Group 12RP Mix
                                                999001000088 - Tambah Orang Ph Std Group 8RP Blok Putih
                                                999001000089 - Tambah Orang Ph Std Group 8RP Mix BlkPth
                                                999001000090 - Tambah Orang Ph Std Group12RP Mix BlkPth
                                                999001000091 - Tambah Orang Ph Std Group 12RP BlkPth
                                                999001000103 - Tambah Orang Ph Std Retouch
                                                999001000104 - Tambah Orang Ph Std Painting
                                                999001000127 - Penambahan Org Ph Std Group 12RP BlkHtm
                                                999001000128 - Penambahan Org PhStd Group12RP MixBLkHtm
                                                999001000129 - Penambahan Org Ph Std Group 8RP BlkHtm
                                                999001000130 - Penambahan Org PhStd Group 8RP MixBLkHtm
                                                999001000134 - Ph Std Priangan Tempo Doeloe Pnmbh Shot
                                                999001000135 - Pnmbhn Org Ph Std Priangan Sajodo
                                                999001000136 - Pnmbhn Org Ph Std Priangan Ngariung
                                                999001000137 - Pnmbhn Org Ph Std Priangan Sasarengan
                                                999001000138 - Photo Studio Penambahan Shoot Casual
                                                999001000139 - Photo Studio Penambahan Shoot Family
                                                999001000140 - Photo Studio Penambahan Shoot Platinum
                                                999001000150 - Penambahan Ganti Baju Photo Studio
                                                            ×999001000103 - Tambah Orang Ph Std Retouch

                            
        
    

    
        
            Additional Pose 

            
                
                    
                                                                        999001000076 - Tambah Orang Ph Std Group 8RP
                                                    999001000078 - Tambah Orang Ph Std Group 12RP
                                                    999001000080 - Tambah orang Ph Std Group 8RP Mix
                                                    999001000082 - Tambah Orang Ph Std Group 12RP Mix
                                                    999001000088 - Tambah Orang Ph Std Group 8RP Blok Putih
                                                    999001000089 - Tambah Orang Ph Std Group 8RP Mix BlkPth
                                                    999001000090 - Tambah Orang Ph Std Group12RP Mix BlkPth
                                                    999001000091 - Tambah Orang Ph Std Group 12RP BlkPth
                                                    999001000103 - Tambah Orang Ph Std Retouch
                                                    999001000104 - Tambah Orang Ph Std Painting
                                                    999001000127 - Penambahan Org Ph Std Group 12RP BlkHtm
                                                    999001000128 - Penambahan Org PhStd Group12RP MixBLkHtm
                                                    999001000129 - Penambahan Org Ph Std Group 8RP BlkHtm
                                                    999001000130 - Penambahan Org PhStd Group 8RP MixBLkHtm
                                                    999001000134 - Ph Std Priangan Tempo Doeloe Pnmbh Shot
                                                    999001000135 - Pnmbhn Org Ph Std Priangan Sajodo
                                                    999001000136 - Pnmbhn Org Ph Std Priangan Ngariung
                                                    999001000137 - Pnmbhn Org Ph Std Priangan Sasarengan
                                                    999001000138 - Photo Studio Penambahan Shoot Casual
                                                    999001000139 - Photo Studio Penambahan Shoot Family
                                                    999001000140 - Photo Studio Penambahan Shoot Platinum
                                                    999001000150 - Penambahan Ganti Baju Photo Studio
                                                            ×999001000138 - Photo Studio Penambahan Shoot Casual

                            
        
    
                
                                    
    
        
            Insentif Value 
            
                

                            
        
    
 Save  Close                
                
                     Previous
                    Next 
                
            </value>
   </webElementProperties>
   <webElementProperties>
      <isSelected>false</isSelected>
      <matchCondition>equals</matchCondition>
      <name>xpath</name>
      <type>Main</type>
      <value>id(&quot;rootwizard&quot;)/div[@class=&quot;tab-content col-sm-12&quot;]</value>
   </webElementProperties>
</WebElementEntity>
